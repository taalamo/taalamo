import 'package:hive_flutter/hive_flutter.dart';
import '../constants/app_constants.dart';

class LocalStorageService {
  static LocalStorageService? _instance;
  static LocalStorageService get instance {
    _instance ??= LocalStorageService._();
    return _instance!;
  }
  LocalStorageService._();

  late Box _settingsBox;
  late Box _progressBox;
  late Box _cacheBox;

  Future<void> init() async {
    _settingsBox = await Hive.openBox(AppConstants.settingsBox);
    _progressBox = await Hive.openBox(AppConstants.progressBox);
    _cacheBox = await Hive.openBox(AppConstants.cacheBox);
  }

  // ─── Settings ──────────────────────────────────────────────────
  bool get isDarkMode =>
      _settingsBox.get(AppConstants.isDarkModeKey, defaultValue: false);

  Future<void> setDarkMode(bool value) =>
      _settingsBox.put(AppConstants.isDarkModeKey, value);

  bool get isFirstLaunch =>
      _settingsBox.get(AppConstants.isFirstLaunchKey, defaultValue: true);

  Future<void> setFirstLaunchDone() =>
      _settingsBox.put(AppConstants.isFirstLaunchKey, false);

  bool get notificationsEnabled =>
      _settingsBox.get(AppConstants.notificationsEnabledKey,
          defaultValue: true);

  Future<void> setNotificationsEnabled(bool value) =>
      _settingsBox.put(AppConstants.notificationsEnabledKey, value);

  String get selectedLanguage =>
      _settingsBox.get(AppConstants.selectedLanguageKey,
          defaultValue: 'ar');

  Future<void> setLanguage(String lang) =>
      _settingsBox.put(AppConstants.selectedLanguageKey, lang);

  // ─── Progress (offline cache) ─────────────────────────────────
  Future<void> saveOfflineLessonProgress(
      String lessonId, bool completed) async {
    await _progressBox.put('lesson_$lessonId', completed);
  }

  bool? getOfflineLessonProgress(String lessonId) {
    return _progressBox.get('lesson_$lessonId');
  }

  Future<void> saveScrollPosition(String courseId, double position) async {
    await _progressBox.put('scroll_$courseId', position);
  }

  double getScrollPosition(String courseId) {
    return _progressBox.get('scroll_$courseId', defaultValue: 0.0);
  }

  // ─── Cache ─────────────────────────────────────────────────────
  Future<void> cacheData(String key, dynamic data) async {
    await _cacheBox.put(key, {
      'data': data,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  dynamic getCachedData(String key, {int maxAgeMinutes = 30}) {
    final entry = _cacheBox.get(key);
    if (entry == null) return null;
    final timestamp = entry['timestamp'] as int;
    final age = DateTime.now().millisecondsSinceEpoch - timestamp;
    if (age > maxAgeMinutes * 60 * 1000) return null;
    return entry['data'];
  }

  Future<void> clearCache() => _cacheBox.clear();

  Future<void> clearAll() async {
    await _settingsBox.clear();
    await _progressBox.clear();
    await _cacheBox.clear();
  }
}
