import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/models.dart';

class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;

  SupabaseClient get client => _client;

  // ─── Auth ──────────────────────────────────────────────────────
  User? get currentUser => _client.auth.currentUser;
  String? get currentUserId => _client.auth.currentUser?.id;
  bool get isLoggedIn => _client.auth.currentUser != null;

  Stream<AuthState> get authStateStream => _client.auth.onAuthStateChange;

  Future<AuthResponse> signInWithEmail(String email, String password) async {
    return await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  Future<AuthResponse> signUpWithEmail(
      String email, String password, String fullName) async {
    final res = await _client.auth.signUp(
      email: email,
      password: password,
      data: {'full_name': fullName},
    );
    return res;
  }

  Future<void> signInWithGoogle() async {
    await _client.auth.signInWithOAuth(
      OAuthProvider.google,
      redirectTo: 'io.supabase.taalamo://login-callback/',
    );
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
  }

  Future<void> resetPassword(String email) async {
    await _client.auth.resetPasswordForEmail(email);
  }

  // ─── User Profile ──────────────────────────────────────────────
  Future<UserModel?> getUserProfile(String userId) async {
    final res = await _client
        .from('users')
        .select()
        .eq('id', userId)
        .maybeSingle();
    if (res == null) return null;
    return UserModel.fromJson(res);
  }

  Future<void> upsertUserProfile(Map<String, dynamic> data) async {
    await _client.from('users').upsert(data);
  }

  Future<void> updateUserProfile(
      String userId, Map<String, dynamic> data) async {
    await _client.from('users').update(data).eq('id', userId);
  }

  // ─── Categories ────────────────────────────────────────────────
  Future<List<CategoryModel>> getCategories() async {
    final res = await _client
        .from('categories')
        .select()
        .eq('is_active', true)
        .order('name_ar');
    return (res as List)
        .map((c) => CategoryModel.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  // ─── Courses ───────────────────────────────────────────────────
  Future<List<CourseModel>> getCourses({
    String? categoryId,
    String? level,
    String? search,
    bool? isFeatured,
    int limit = 20,
    int offset = 0,
  }) async {
    var query = _client
        .from('courses')
        .select('*, categories(*)')
        .eq('is_active', true);

    if (categoryId != null) query = query.eq('category_id', categoryId);
    if (level != null) query = query.eq('level', level);
    if (isFeatured != null) query = query.eq('is_featured', isFeatured);
    if (search != null && search.isNotEmpty) {
      query = query.ilike('title_ar', '%$search%');
    }

    final res = await query
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);

    return (res as List)
        .map((c) => CourseModel.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  Future<CourseModel?> getCourseById(String id) async {
    final res = await _client
        .from('courses')
        .select('*, categories(*)')
        .eq('id', id)
        .maybeSingle();
    if (res == null) return null;

    // Check enrollment if logged in
    if (isLoggedIn) {
      final enrollment = await _client
          .from('user_course_enrollments')
          .select('completion_percentage')
          .eq('user_id', currentUserId!)
          .eq('course_id', id)
          .maybeSingle();

      final map = Map<String, dynamic>.from(res);
      if (enrollment != null) {
        map['completion_percentage'] = enrollment['completion_percentage'];
        map['is_enrolled'] = true;
      }
      return CourseModel.fromJson(map);
    }

    return CourseModel.fromJson(res as Map<String, dynamic>);
  }

  Future<List<CourseModel>> getEnrolledCourses() async {
    if (!isLoggedIn) return [];
    final res = await _client
        .from('user_course_enrollments')
        .select('completion_percentage, courses(*, categories(*))')
        .eq('user_id', currentUserId!)
        .order('last_accessed_at', ascending: false);

    return (res as List).map((row) {
      final courseData =
          Map<String, dynamic>.from(row['courses'] as Map<String, dynamic>);
      courseData['completion_percentage'] = row['completion_percentage'];
      courseData['is_enrolled'] = true;
      return CourseModel.fromJson(courseData);
    }).toList();
  }

  // ─── Lessons ───────────────────────────────────────────────────
  Future<List<LessonModel>> getCourseLessons(String courseId) async {
    var query = _client
        .from('lessons')
        .select()
        .eq('course_id', courseId)
        .eq('is_active', true)
        .order('order_index');

    final res = await query;

    // If logged in, get completed status
    if (isLoggedIn) {
      final progress = await _client
          .from('user_progress')
          .select('lesson_id, is_completed')
          .eq('user_id', currentUserId!)
          .eq('course_id', courseId);

      final progressMap = {
        for (final p in (progress as List))
          p['lesson_id'] as String: p['is_completed'] as bool
      };

      return (res as List).map((l) {
        final map = Map<String, dynamic>.from(l as Map<String, dynamic>);
        map['is_completed'] = progressMap[map['id']] ?? false;
        return LessonModel.fromJson(map);
      }).toList();
    }

    return (res as List)
        .map((l) => LessonModel.fromJson(l as Map<String, dynamic>))
        .toList();
  }

  // ─── Enrollment ────────────────────────────────────────────────
  Future<void> enrollCourse(String courseId) async {
    if (!isLoggedIn) return;
    await _client.from('user_course_enrollments').upsert({
      'user_id': currentUserId,
      'course_id': courseId,
      'enrolled_at': DateTime.now().toIso8601String(),
      'last_accessed_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> updateLessonProgress(
      String courseId, String lessonId, bool completed) async {
    if (!isLoggedIn) return;
    await _client.from('user_progress').upsert({
      'user_id': currentUserId,
      'course_id': courseId,
      'lesson_id': lessonId,
      'is_completed': completed,
      'completed_at': completed ? DateTime.now().toIso8601String() : null,
    });

    // Update enrollment progress
    await _updateCourseProgress(courseId);
  }

  Future<void> _updateCourseProgress(String courseId) async {
    if (!isLoggedIn) return;
    // Count total and completed lessons
    final total = await _client
        .from('lessons')
        .select('id')
        .eq('course_id', courseId)
        .eq('is_active', true);
    final completed = await _client
        .from('user_progress')
        .select('id')
        .eq('user_id', currentUserId!)
        .eq('course_id', courseId)
        .eq('is_completed', true);

    final totalCount = (total as List).length;
    final completedCount = (completed as List).length;
    final percentage =
        totalCount > 0 ? (completedCount / totalCount * 100) : 0.0;

    await _client.from('user_course_enrollments').update({
      'completion_percentage': percentage,
      'completed_at': percentage >= 100
          ? DateTime.now().toIso8601String()
          : null,
      'last_accessed_at': DateTime.now().toIso8601String(),
    }).eq('user_id', currentUserId!).eq('course_id', courseId);
  }

  // ─── Quizzes ───────────────────────────────────────────────────
  Future<List<QuizModel>> getCourseQuizzes(String courseId) async {
    final res = await _client
        .from('quizzes')
        .select('*, questions(*)')
        .eq('course_id', courseId)
        .eq('is_active', true);

    return (res as List)
        .map((q) => QuizModel.fromJson(q as Map<String, dynamic>))
        .toList();
  }

  Future<void> submitQuizAttempt({
    required String quizId,
    required double score,
    required int totalQuestions,
    required int correctAnswers,
    required bool passed,
    required Map<String, dynamic> answers,
    int? timeTakenSeconds,
  }) async {
    if (!isLoggedIn) return;
    await _client.from('user_quiz_attempts').insert({
      'user_id': currentUserId,
      'quiz_id': quizId,
      'score': score,
      'total_questions': totalQuestions,
      'correct_answers': correctAnswers,
      'passed': passed,
      'answers': answers,
      'time_taken_seconds': timeTakenSeconds,
    });

    if (passed) {
      await _addXp(20, 'quiz_pass', 'quiz_pass');
    }
  }

  // ─── XP & Gamification ─────────────────────────────────────────
  Future<void> _addXp(int amount, String reason, String reasonType) async {
    if (!isLoggedIn) return;
    await _client.from('xp_transactions').insert({
      'user_id': currentUserId,
      'xp_amount': amount,
      'reason': reason,
      'reason_type': reasonType,
    });

    // Update user total_xp
    await _client.rpc('increment_user_xp', params: {
      'uid': currentUserId,
      'xp': amount,
    });
  }

  // ─── Certificates ──────────────────────────────────────────────
  Future<List<CertificateModel>> getUserCertificates() async {
    if (!isLoggedIn) return [];
    final res = await _client
        .from('certificates')
        .select('*, courses(title, title_ar, thumbnail_url)')
        .eq('user_id', currentUserId!)
        .order('issued_at', ascending: false);

    return (res as List)
        .map((c) => CertificateModel.fromJson(c as Map<String, dynamic>))
        .toList();
  }

  Future<CertificateModel?> requestCertificate(
      String courseId, String displayName) async {
    if (!isLoggedIn) return null;
    final res = await _client.from('certificates').upsert({
      'user_id': currentUserId,
      'course_id': courseId,
      'display_name': displayName,
      'issued_at': DateTime.now().toIso8601String(),
    }).select().single();

    return CertificateModel.fromJson(res as Map<String, dynamic>);
  }

  // ─── Badges ────────────────────────────────────────────────────
  Future<List<BadgeModel>> getUserBadges() async {
    if (!isLoggedIn) return [];
    final res = await _client
        .from('user_badges')
        .select('earned_at, badges(*)')
        .eq('user_id', currentUserId!)
        .order('earned_at', ascending: false);

    return (res as List).map((row) {
      final badgeData =
          Map<String, dynamic>.from(row['badges'] as Map<String, dynamic>);
      badgeData['earned_at'] = row['earned_at'];
      return BadgeModel.fromJson(badgeData);
    }).toList();
  }

  // ─── Saved Courses ─────────────────────────────────────────────
  Future<void> toggleSaveCourse(String courseId) async {
    if (!isLoggedIn) return;
    final existing = await _client
        .from('user_saved_courses')
        .select('id')
        .eq('user_id', currentUserId!)
        .eq('course_id', courseId)
        .maybeSingle();

    if (existing != null) {
      await _client
          .from('user_saved_courses')
          .delete()
          .eq('user_id', currentUserId!)
          .eq('course_id', courseId);
    } else {
      await _client.from('user_saved_courses').insert({
        'user_id': currentUserId,
        'course_id': courseId,
      });
    }
  }

  Future<bool> isCourseSaved(String courseId) async {
    if (!isLoggedIn) return false;
    final res = await _client
        .from('user_saved_courses')
        .select('id')
        .eq('user_id', currentUserId!)
        .eq('course_id', courseId)
        .maybeSingle();
    return res != null;
  }

  // ─── Notifications ─────────────────────────────────────────────
  Future<List<Map<String, dynamic>>> getNotifications() async {
    if (!isLoggedIn) return [];
    final res = await _client
        .from('notifications')
        .select()
        .eq('user_id', currentUserId!)
        .order('created_at', ascending: false)
        .limit(20);
    return (res as List).cast<Map<String, dynamic>>();
  }

  Future<void> markNotificationRead(String id) async {
    await _client
        .from('notifications')
        .update({'is_read': true})
        .eq('id', id);
  }

  // ─── Push Token ────────────────────────────────────────────────
  Future<void> savePushToken(String token) async {
    if (!isLoggedIn) return;
    await _client.from('push_notification_tokens').upsert({
      'user_id': currentUserId,
      'token': token,
      'platform': 'android',
    });
  }
}

// ─── Global instance ──────────────────────────────────────────────────────────
final supabaseService = SupabaseService();
