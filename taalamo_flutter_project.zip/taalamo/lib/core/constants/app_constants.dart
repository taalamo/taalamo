class AppConstants {
  // ─── Supabase ──────────────────────────────────────────────────
  static const String supabaseUrl = 'https://aigfhxrvfotgccfnovtv.supabase.co';
  static const String supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFpZ2ZoeHJ2Zm90Z2NjZm5vdnR2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUxMDUwMzMsImV4cCI6MjA5MDY4MTAzM30.OUNysEIRdBUeQYzgH-XcIdupRdKPBpIFl5YvHLEjYps';

  // ─── App Info ──────────────────────────────────────────────────
  static const String appName = 'تعلّمو';
  static const String appVersion = '1.0.0';

  // ─── Hive Box Names ────────────────────────────────────────────
  static const String settingsBox = 'settings_box';
  static const String progressBox = 'progress_box';
  static const String cacheBox = 'cache_box';

  // ─── Secure Storage Keys ───────────────────────────────────────
  static const String accessTokenKey = 'access_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userIdKey = 'user_id';

  // ─── Settings Keys ─────────────────────────────────────────────
  static const String isDarkModeKey = 'is_dark_mode';
  static const String isFirstLaunchKey = 'is_first_launch';
  static const String selectedLanguageKey = 'selected_language';
  static const String notificationsEnabledKey = 'notifications_enabled';

  // ─── Gamification ──────────────────────────────────────────────
  static const int xpPerLesson = 10;
  static const int xpPerQuizPass = 20;
  static const int xpPerCourseComplete = 100;
  static const int xpPerStreakDay = 5;

  // ─── Pagination ────────────────────────────────────────────────
  static const int defaultPageSize = 10;
  static const int coursesPageSize = 12;

  // ─── YouTube ───────────────────────────────────────────────────
  static const String youtubeBaseUrl = 'https://www.youtube.com/watch?v=';
  static const String youtubeThumbnailUrl =
      'https://img.youtube.com/vi/{videoId}/mqdefault.jpg';

  // ─── Durations ─────────────────────────────────────────────────
  static const Duration animationFast = Duration(milliseconds: 200);
  static const Duration animationMedium = Duration(milliseconds: 350);
  static const Duration animationSlow = Duration(milliseconds: 500);
  static const Duration snackBarDuration = Duration(seconds: 3);

  // ─── Levels ────────────────────────────────────────────────────
  static const Map<int, int> levelXpThresholds = {
    1: 0,
    2: 100,
    3: 250,
    4: 500,
    5: 1000,
    6: 1750,
    7: 2750,
    8: 4000,
    9: 5500,
    10: 7500,
  };

  static int getLevelFromXp(int xp) {
    int level = 1;
    for (final entry in levelXpThresholds.entries) {
      if (xp >= entry.value) {
        level = entry.key;
      }
    }
    return level;
  }

  static int getXpForNextLevel(int currentLevel) {
    final next = currentLevel + 1;
    return levelXpThresholds[next] ?? levelXpThresholds[10]!;
  }
}
