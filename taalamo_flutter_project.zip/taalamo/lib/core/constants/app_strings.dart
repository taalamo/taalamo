class AppStrings {
  // ─── App ───────────────────────────────────────────────────────
  static const String appName = 'تعلّمو';
  static const String appTagline = 'تعلّم أي شيء، في أي وقت';

  // ─── Auth ──────────────────────────────────────────────────────
  static const String login = 'تسجيل الدخول';
  static const String register = 'إنشاء حساب';
  static const String logout = 'تسجيل الخروج';
  static const String email = 'البريد الإلكتروني';
  static const String password = 'كلمة المرور';
  static const String confirmPassword = 'تأكيد كلمة المرور';
  static const String fullName = 'الاسم الكامل';
  static const String forgotPassword = 'نسيت كلمة المرور؟';
  static const String resetPassword = 'استعادة كلمة المرور';
  static const String continueWithGoogle = 'متابعة مع Google';
  static const String noAccount = 'ليس لديك حساب؟ ';
  static const String haveAccount = 'لديك حساب بالفعل؟ ';
  static const String or = 'أو';
  static const String agreeTerms = 'أوافق على ';
  static const String termsAndConditions = 'الشروط والأحكام';
  static const String privacyPolicy = 'سياسة الخصوصية';

  // ─── Navigation ────────────────────────────────────────────────
  static const String home = 'الرئيسية';
  static const String courses = 'الكورسات';
  static const String search = 'البحث';
  static const String profile = 'حسابي';

  // ─── Home ──────────────────────────────────────────────────────
  static const String continuelearning = 'متابعة التعلم';
  static const String featuredCourses = '🔥 الكورسات المميزة';
  static const String newCourses = '✨ كورسات جديدة';
  static const String seeAll = 'الكل';
  static const String searchPlaceholder = 'ابحث عن كورس...';

  // ─── Courses ───────────────────────────────────────────────────
  static const String allCourses = 'جميع الكورسات';
  static const String allLevels = 'الكل';
  static const String beginner = 'مبتدئ';
  static const String intermediate = 'متوسط';
  static const String advanced = 'متقدم';
  static const String free = 'مجاني';
  static const String paid = 'مدفوع';
  static const String lessons = 'درس';
  static const String minutes = 'دقيقة';
  static const String hours = 'ساعة';
  static const String rating = 'تقييم';
  static const String enrollFree = 'سجّل مجاناً';
  static const String continueLearning = 'متابعة التعلم';
  static const String startLearning = 'ابدأ التعلم';
  static const String completed = 'مكتمل';
  static const String progress = 'التقدم';

  // ─── Lessons ───────────────────────────────────────────────────
  static const String previousLesson = 'السابق';
  static const String nextLesson = 'التالي';
  static const String lessonCompleted = '✅ تم إكمال الدرس!';
  static const String lessonsList = 'قائمة الدروس';
  static const String notes = 'ملاحظات';
  static const String freePreview = 'مجاني';
  static const String enrollToAccess = 'سجّل في الكورس للوصول إلى هذا الدرس';

  // ─── Quiz ──────────────────────────────────────────────────────
  static const String quiz = 'اختبار';
  static const String quizzes = 'الاختبارات';
  static const String question = 'سؤال';
  static const String from = 'من';
  static const String answered = 'تمت الإجابة';
  static const String submitQuiz = 'تسليم الاختبار';
  static const String endQuiz = 'إنهاء الاختبار؟';
  static const String willLoseAnswers = 'سيتم فقدان إجاباتك الحالية';
  static const String cancel = 'إلغاء';
  static const String exit = 'خروج';
  static const String quizResult = 'نتيجة الاختبار';
  static const String wellDone = '🎉 أحسنت!';
  static const String tryAgain = '💪 حاول مرة أخرى';
  static const String correct = 'صحيح';
  static const String wrong = 'خطأ';
  static const String toPass = 'للنجاح';
  static const String reviewAnswers = 'مراجعة الإجابات';
  static const String yourAnswer = 'إجابتك';
  static const String correctAnswer = 'الإجابة الصحيحة';
  static const String backToCourse = 'العودة للكورس';
  static const String retakeQuiz = 'إعادة الاختبار';

  // ─── Certificate ───────────────────────────────────────────────
  static const String certificate = 'شهادة الإتمام';
  static const String certificateOf = 'شهادة إتمام';
  static const String certifyThat = 'يُشهد بأن';
  static const String completedCourse = 'قد أتمّ بنجاح كورس';
  static const String certName = 'الاسم على الشهادة';
  static const String generateCert = 'إنشاء الشهادة 🏆';
  static const String shareCert = 'مشاركة الشهادة';
  static const String issuedOn = 'تاريخ الإصدار:';

  // ─── Profile ───────────────────────────────────────────────────
  static const String myProfile = 'ملفي الشخصي';
  static const String level = 'المستوى';
  static const String xpPoints = 'نقاط XP';
  static const String streakDays = 'أيام متواصلة';
  static const String enrolledCourses = 'كورس مسجّل';
  static const String certificates = 'شهادة';
  static const String myCourses = 'الكورسات';
  static const String myBadges = 'الشارات';
  static const String myCertificates = 'الشهادات';
  static const String settings = 'الإعدادات';
  static const String darkMode = 'الوضع الليلي';
  static const String notifications = 'الإشعارات';
  static const String aboutApp = 'عن التطبيق';

  // ─── Errors ────────────────────────────────────────────────────
  static const String errorOccurred = 'حدث خطأ';
  static const String retry = 'إعادة المحاولة';
  static const String noInternet = 'لا يوجد اتصال بالإنترنت';
  static const String noResults = 'لا توجد نتائج';
  static const String loading = 'جاري التحميل...';
  static const String pleaseWait = 'يرجى الانتظار';

  // ─── Success messages ──────────────────────────────────────────
  static const String enrolledSuccess = 'تم التسجيل في الكورس!';
  static const String savedSuccess = 'تم الحفظ بنجاح';
  static const String certCreatedSuccess = 'تم إنشاء شهادتك بنجاح! 🎉';
  static const String passwordResetSent =
      'تم إرسال رابط الاستعادة إلى بريدك';
}
