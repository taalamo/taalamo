import 'package:flutter/material.dart';

class AppUtils {
  // ─── Duration formatting ───────────────────────────────────────
  static String formatDuration(int seconds) {
    if (seconds < 60) return '${seconds}ث';
    final m = seconds ~/ 60;
    final s = seconds % 60;
    if (m < 60) {
      return s > 0 ? '${m}د ${s}ث' : '${m}د';
    }
    final h = m ~/ 60;
    final remainM = m % 60;
    return remainM > 0 ? '${h}س ${remainM}د' : '${h}س';
  }

  static String formatMinutes(int minutes) {
    if (minutes < 60) return '$minutes دقيقة';
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return m > 0 ? '$h ساعة و$m دقيقة' : '$h ساعة';
  }

  // ─── Date formatting ───────────────────────────────────────────
  static String formatDateArabic(DateTime date) {
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  static String timeAgo(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);

    if (diff.inSeconds < 60) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
    if (diff.inDays < 7) return 'منذ ${diff.inDays} يوم';
    if (diff.inDays < 30) return 'منذ ${(diff.inDays / 7).floor()} أسبوع';
    if (diff.inDays < 365) return 'منذ ${(diff.inDays / 30).floor()} شهر';
    return 'منذ ${(diff.inDays / 365).floor()} سنة';
  }

  // ─── Number formatting ─────────────────────────────────────────
  static String formatCount(int count) {
    if (count < 1000) return '$count';
    if (count < 1000000) return '${(count / 1000).toStringAsFixed(1)}k';
    return '${(count / 1000000).toStringAsFixed(1)}M';
  }

  // ─── Level helpers ─────────────────────────────────────────────
  static String getLevelLabel(String level) {
    const map = {
      'beginner': 'مبتدئ',
      'intermediate': 'متوسط',
      'advanced': 'متقدم',
    };
    return map[level] ?? level;
  }

  static Color getLevelColor(String level) {
    const map = {
      'beginner': Color(0xFF27AE60),
      'intermediate': Color(0xFFF39C12),
      'advanced': Color(0xFFE74C3C),
    };
    return map[level] ?? const Color(0xFF27AE60);
  }

  // ─── YouTube helpers ───────────────────────────────────────────
  static String? extractYoutubeVideoId(String url) {
    final regExp = RegExp(
      r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)'
      r'([a-zA-Z0-9_-]{11})',
    );
    final match = regExp.firstMatch(url);
    return match?.group(1);
  }

  static String getYoutubeThumbnail(String videoId) {
    return 'https://img.youtube.com/vi/$videoId/mqdefault.jpg';
  }

  // ─── Validation ────────────────────────────────────────────────
  static bool isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  static bool isValidPassword(String password) {
    return password.length >= 8;
  }

  // ─── Snackbar shortcut ─────────────────────────────────────────
  static void showSnack(BuildContext context, String msg,
      {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'Cairo')),
        backgroundColor: isError
            ? const Color(0xFFE74C3C)
            : const Color(0xFF27AE60),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }
}
