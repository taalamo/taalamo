import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

import '../../themes/app_colors.dart';
import '../../providers/providers.dart';
import '../../../data/models/models.dart';

class CoursesScreen extends ConsumerStatefulWidget {
  const CoursesScreen({super.key});

  @override
  ConsumerState<CoursesScreen> createState() => _CoursesScreenState();
}

class _CoursesScreenState extends ConsumerState<CoursesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String? _selectedLevel;

  static const _levels = [
    {'key': null, 'label': 'الكل'},
    {'key': 'beginner', 'label': 'مبتدئ'},
    {'key': 'intermediate', 'label': 'متوسط'},
    {'key': 'advanced', 'label': 'متقدم'},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _levels.length, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        final level = _levels[_tabController.index]['key'] as String?;
        setState(() => _selectedLevel = level);
        ref.read(coursesFilterProvider.notifier).update(
              (state) => state.copyWith(level: level),
            );
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categoriesAsync = ref.watch(categoriesProvider);
    final coursesAsync = ref.watch(coursesProvider);
    final filter = ref.watch(coursesFilterProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('الكورسات'),
        backgroundColor: Colors.white,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(44),
          child: TabBar(
            controller: _tabController,
            labelStyle: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
            unselectedLabelStyle: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.w400,
              fontSize: 13,
            ),
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.textSecondary,
            indicatorColor: AppColors.primary,
            indicatorWeight: 2.5,
            tabs: _levels
                .map((l) => Tab(text: l['label'] as String))
                .toList(),
          ),
        ),
      ),
      body: Column(
        children: [
          // ─── Category Filter ──────────────────────────────────
          categoriesAsync.when(
            data: (cats) => _CategoryFilter(
              categories: cats,
              selected: filter.categoryId,
              onSelect: (id) {
                ref.read(coursesFilterProvider.notifier).update(
                      (state) => state.copyWith(categoryId: id),
                    );
              },
            ),
            loading: () => const SizedBox(height: 56),
            error: (_, __) => const SizedBox.shrink(),
          ),

          // ─── Course List ──────────────────────────────────────
          Expanded(
            child: coursesAsync.when(
              data: (courses) => courses.isEmpty
                  ? _EmptyState()
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                      itemCount: courses.length,
                      itemBuilder: (_, i) =>
                          _CourseListCard(course: courses[i]),
                    ),
              loading: () => _CoursesShimmer(),
              error: (e, _) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline,
                        color: AppColors.error, size: 48),
                    const SizedBox(height: 12),
                    Text('حدث خطأ في التحميل',
                        style: const TextStyle(fontFamily: 'Cairo')),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () => ref.refresh(coursesProvider),
                      child: const Text('إعادة المحاولة',
                          style: TextStyle(fontFamily: 'Cairo')),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryFilter extends StatelessWidget {
  final List<CategoryModel> categories;
  final String? selected;
  final ValueChanged<String?> onSelect;

  const _CategoryFilter({
    required this.categories,
    required this.selected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      color: Colors.white,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: [
          // All chip
          _Chip(
            label: 'الكل',
            isSelected: selected == null,
            onTap: () => onSelect(null),
          ),
          ...categories.map(
            (cat) => _Chip(
              label: cat.displayName,
              isSelected: selected == cat.id,
              onTap: () => onSelect(cat.id),
            ),
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _Chip({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.inputFill,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: isSelected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _CourseListCard extends StatelessWidget {
  final CourseModel course;

  const _CourseListCard({required this.course});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/course/${course.id}'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: AppColors.elevatedCardShadow,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
              child: course.thumbnailUrl != null
                  ? CachedNetworkImage(
                      imageUrl: course.thumbnailUrl!,
                      height: 160,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      placeholder: (_, __) => Container(
                        height: 160,
                        color: AppColors.primaryLight,
                        child: const Center(
                          child: Icon(Icons.play_circle_outline,
                              color: AppColors.primary, size: 48),
                        ),
                      ),
                    )
                  : Container(
                      height: 160,
                      decoration: const BoxDecoration(
                        gradient: AppColors.primaryGradient,
                      ),
                      child: const Center(
                        child: Icon(Icons.play_circle_outline,
                            color: Colors.white, size: 56),
                      ),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category + Level row
                  Row(
                    children: [
                      if (course.category != null)
                        _Tag(
                          text: course.category!.displayName,
                          color: AppColors.primary,
                        ),
                      const SizedBox(width: 8),
                      _LevelTag(level: course.level),
                      const Spacer(),
                      if (!course.isFree)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.accentLight,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'مدفوع',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: AppColors.accent,
                            ),
                          ),
                        )
                      else
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.primaryLight,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'مجاني',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    course.displayTitle,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (course.displayDescription.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      course.displayDescription,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 13,
                        color: AppColors.textSecondary,
                        height: 1.4,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(Icons.play_lesson_outlined,
                          size: 15, color: AppColors.textHint),
                      const SizedBox(width: 4),
                      Text(
                        '${course.totalLessons} درس',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(width: 16),
                      const Icon(Icons.schedule_outlined,
                          size: 15, color: AppColors.textHint),
                      const SizedBox(width: 4),
                      Text(
                        '${course.totalDurationMinutes} دقيقة',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      if (course.avgRating > 0) ...[
                        const Spacer(),
                        const Icon(Icons.star_rounded,
                            size: 15, color: AppColors.xpGold),
                        const SizedBox(width: 3),
                        Text(
                          course.avgRating.toStringAsFixed(1),
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String text;
  final Color color;

  const _Tag({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 11,
          color: color,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _LevelTag extends StatelessWidget {
  final String level;

  const _LevelTag({required this.level});

  static const _map = {
    'beginner': ('مبتدئ', AppColors.levelBeginner),
    'intermediate': ('متوسط', AppColors.levelIntermediate),
    'advanced': ('متقدم', AppColors.levelAdvanced),
  };

  @override
  Widget build(BuildContext context) {
    final data = _map[level] ?? ('مبتدئ', AppColors.levelBeginner);
    return _Tag(text: data.$1, color: data.$2);
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🔍', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 16),
          const Text(
            'لا توجد كورسات بهذا التصنيف',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'جرب تصنيفاً آخر',
            style: TextStyle(
              fontFamily: 'Cairo',
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _CoursesShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[200]!,
      highlightColor: Colors.grey[50]!,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
        itemCount: 4,
        itemBuilder: (_, __) => Container(
          height: 280,
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      ),
    );
  }
}
