import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:shimmer/shimmer.dart';

import '../../themes/app_colors.dart';
import '../../providers/providers.dart';
import '../../../data/models/models.dart';
import '../../../core/services/supabase_service.dart';
import '../../widgets/common/app_snackbar.dart';
import '../../widgets/common/custom_button.dart';

class CourseDetailScreen extends ConsumerStatefulWidget {
  final String courseId;

  const CourseDetailScreen({super.key, required this.courseId});

  @override
  ConsumerState<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends ConsumerState<CourseDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _enrolling = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _enroll(CourseModel course) async {
    if (!supabaseService.isLoggedIn) {
      context.go('/auth/login');
      return;
    }
    setState(() => _enrolling = true);
    try {
      await supabaseService.enrollCourse(course.id);
      ref.refresh(courseDetailProvider(widget.courseId));
      ref.refresh(enrolledCoursesProvider);
      if (mounted) AppSnackbar.success(context, 'تم التسجيل في الكورس!');
    } catch (e) {
      if (mounted) AppSnackbar.error(context, 'حدث خطأ في التسجيل');
    } finally {
      if (mounted) setState(() => _enrolling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final courseAsync = ref.watch(courseDetailProvider(widget.courseId));
    final lessonsAsync = ref.watch(courseLessonsProvider(widget.courseId));
    final quizzesAsync = ref.watch(courseQuizzesProvider(widget.courseId));

    return Scaffold(
      backgroundColor: AppColors.background,
      body: courseAsync.when(
        data: (course) {
          if (course == null) {
            return const Center(
              child: Text('الكورس غير موجود',
                  style: TextStyle(fontFamily: 'Cairo')),
            );
          }
          return _buildContent(course, lessonsAsync, quizzesAsync);
        },
        loading: () => const _CourseDetailShimmer(),
        error: (e, _) => Center(
          child: Text('حدث خطأ: $e',
              style: const TextStyle(fontFamily: 'Cairo')),
        ),
      ),
    );
  }

  Widget _buildContent(
    CourseModel course,
    AsyncValue<List<LessonModel>> lessonsAsync,
    AsyncValue<List<QuizModel>> quizzesAsync,
  ) {
    final completion = course.completionPercentage ?? 0.0;
    final isEnrolled = course.isEnrolled ?? false;

    return CustomScrollView(
      slivers: [
        // ─── Hero AppBar ────────────────────────────────────────
        SliverAppBar(
          expandedHeight: 220,
          pinned: true,
          backgroundColor: AppColors.primary,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
            onPressed: () => context.pop(),
          ),
          actions: [
            Consumer(builder: (context, ref, _) {
              final savedAsync =
                  ref.watch(courseSavedProvider(widget.courseId));
              return savedAsync.when(
                data: (saved) => IconButton(
                  icon: Icon(
                    saved ? Icons.bookmark : Icons.bookmark_border,
                    color: Colors.white,
                  ),
                  onPressed: () async {
                    await supabaseService.toggleSaveCourse(course.id);
                    ref.refresh(courseSavedProvider(widget.courseId));
                  },
                ),
                loading: () => const SizedBox.shrink(),
                error: (_, __) => const SizedBox.shrink(),
              );
            }),
          ],
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(
              fit: StackFit.expand,
              children: [
                course.thumbnailUrl != null
                    ? CachedNetworkImage(
                        imageUrl: course.thumbnailUrl!,
                        fit: BoxFit.cover,
                      )
                    : Container(
                        decoration: const BoxDecoration(
                          gradient: AppColors.heroGradient,
                        ),
                      ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.3),
                        Colors.black.withOpacity(0.7),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        SliverToBoxAdapter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ─── Course Info ───────────────────────────────────
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Category + Level
                    Row(
                      children: [
                        if (course.category != null)
                          _TagBadge(
                            text: course.category!.displayName,
                            color: AppColors.primary,
                          ),
                        const SizedBox(width: 8),
                        _TagBadge(
                          text: _levelLabel(course.level),
                          color: _levelColor(course.level),
                        ),
                        const SizedBox(width: 8),
                        if (!course.isFree)
                          _TagBadge(
                            text: 'مدفوع',
                            color: AppColors.accent,
                          )
                        else
                          _TagBadge(
                            text: 'مجاني',
                            color: AppColors.success,
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      course.displayTitle,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    if (course.displayDescription.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(
                        course.displayDescription,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 14,
                          color: AppColors.textSecondary,
                          height: 1.6,
                        ),
                      ),
                    ],
                    const SizedBox(height: 16),
                    // Stats row
                    Row(
                      children: [
                        _StatItem(
                          icon: Icons.play_lesson_outlined,
                          value: '${course.totalLessons}',
                          label: 'درس',
                        ),
                        const SizedBox(width: 20),
                        _StatItem(
                          icon: Icons.schedule_outlined,
                          value: '${course.totalDurationMinutes}',
                          label: 'دقيقة',
                        ),
                        if (course.avgRating > 0) ...[
                          const SizedBox(width: 20),
                          _StatItem(
                            icon: Icons.star_rounded,
                            value: course.avgRating.toStringAsFixed(1),
                            label: 'تقييم',
                            iconColor: AppColors.xpGold,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),

              // ─── Progress Bar (if enrolled) ────────────────────
              if (isEnrolled && completion > 0)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.primarySurface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.primaryLight),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'تقدمك في الكورس',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          Text(
                            '${completion.toInt()}%',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.w700,
                              color: AppColors.primary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      LinearPercentIndicator(
                        padding: EdgeInsets.zero,
                        lineHeight: 8,
                        percent: (completion / 100).clamp(0.0, 1.0),
                        progressColor: AppColors.primary,
                        backgroundColor: AppColors.primaryLight,
                        barRadius: const Radius.circular(4),
                      ),
                      if (completion >= 100) ...[
                        const SizedBox(height: 10),
                        ElevatedButton.icon(
                          onPressed: () =>
                              context.push('/certificate/${course.id}'),
                          icon: const Icon(Icons.workspace_premium, size: 18),
                          label: const Text('احصل على شهادتك',
                              style: TextStyle(fontFamily: 'Cairo')),
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size(double.infinity, 42),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

              const SizedBox(height: 20),

              // ─── Tab Bar ───────────────────────────────────────
              Container(
                color: Colors.white,
                child: TabBar(
                  controller: _tabController,
                  labelColor: AppColors.primary,
                  unselectedLabelColor: AppColors.textSecondary,
                  indicatorColor: AppColors.primary,
                  labelStyle: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.w600,
                  ),
                  tabs: const [
                    Tab(text: 'الدروس'),
                    Tab(text: 'الاختبارات'),
                  ],
                ),
              ),

              // ─── Tab Content ───────────────────────────────────
              SizedBox(
                height: 500,
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    // Lessons Tab
                    lessonsAsync.when(
                      data: (lessons) => ListView.builder(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        itemCount: lessons.length,
                        itemBuilder: (_, i) => _LessonTile(
                          lesson: lessons[i],
                          index: i + 1,
                          isEnrolled: isEnrolled,
                          courseId: widget.courseId,
                        ),
                      ),
                      loading: () =>
                          const Center(child: CircularProgressIndicator()),
                      error: (_, __) => const Center(
                          child: Text('تعذر تحميل الدروس',
                              style: TextStyle(fontFamily: 'Cairo'))),
                    ),
                    // Quizzes Tab
                    quizzesAsync.when(
                      data: (quizzes) => quizzes.isEmpty
                          ? const Center(
                              child: Text('لا توجد اختبارات بعد',
                                  style: TextStyle(fontFamily: 'Cairo')))
                          : ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: quizzes.length,
                              itemBuilder: (_, i) =>
                                  _QuizTile(quiz: quizzes[i]),
                            ),
                      loading: () =>
                          const Center(child: CircularProgressIndicator()),
                      error: (_, __) => const SizedBox.shrink(),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 100),
            ],
          ),
        ),
      ],
    );
  }

  String _levelLabel(String level) {
    const map = {
      'beginner': 'مبتدئ',
      'intermediate': 'متوسط',
      'advanced': 'متقدم',
    };
    return map[level] ?? level;
  }

  Color _levelColor(String level) {
    const map = {
      'beginner': AppColors.levelBeginner,
      'intermediate': AppColors.levelIntermediate,
      'advanced': AppColors.levelAdvanced,
    };
    return map[level] ?? AppColors.levelBeginner;
  }

  Widget _buildEnrollButton(CourseModel course) {
    final isEnrolled = course.isEnrolled ?? false;
    if (isEnrolled) {
      return CustomButton(
        text: 'متابعة التعلم',
        icon: Icons.play_arrow_rounded,
        onPressed: () {},
      );
    }
    return CustomButton(
      text: course.isFree ? 'سجّل مجاناً' : 'الاشتراك في الكورس',
      icon: Icons.school_outlined,
      onPressed: () => _enroll(course),
      isLoading: _enrolling,
    );
  }
}

class _TagBadge extends StatelessWidget {
  final String text;
  final Color color;

  const _TagBadge({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 11,
          color: color,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color iconColor;

  const _StatItem({
    required this.icon,
    required this.value,
    required this.label,
    this.iconColor = AppColors.textHint,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16, color: iconColor),
        const SizedBox(width: 4),
        Text(
          '$value $label',
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 13,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _LessonTile extends StatelessWidget {
  final LessonModel lesson;
  final int index;
  final bool isEnrolled;
  final String courseId;

  const _LessonTile({
    required this.lesson,
    required this.index,
    required this.isEnrolled,
    required this.courseId,
  });

  @override
  Widget build(BuildContext context) {
    final isCompleted = lesson.isCompleted ?? false;

    return GestureDetector(
      onTap: () {
        if (isEnrolled || lesson.isFreePreview) {
          context.push('/lesson/$courseId/${lesson.id}');
        } else {
          AppSnackbar.info(context, 'سجّل في الكورس للوصول إلى هذا الدرس');
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isCompleted ? AppColors.primaryLight : AppColors.border,
          ),
        ),
        child: Row(
          children: [
            // Index / Check
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: isCompleted
                    ? AppColors.primary
                    : AppColors.primaryLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: isCompleted
                    ? const Icon(Icons.check, color: Colors.white, size: 18)
                    : Text(
                        '$index',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primary,
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    lesson.displayTitle,
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                      decoration: isCompleted
                          ? TextDecoration.none
                          : null,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.schedule,
                          size: 12, color: AppColors.textHint),
                      const SizedBox(width: 3),
                      Text(
                        lesson.durationFormatted,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 11,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      if (lesson.isFreePreview) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            color: AppColors.secondaryLight,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'مجاني',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 10,
                              color: AppColors.secondary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            // Play icon
            Icon(
              isEnrolled || lesson.isFreePreview
                  ? Icons.play_circle_outline
                  : Icons.lock_outline,
              color: isEnrolled || lesson.isFreePreview
                  ? AppColors.primary
                  : AppColors.textHint,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }
}

class _QuizTile extends StatelessWidget {
  final QuizModel quiz;

  const _QuizTile({required this.quiz});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/quiz/${quiz.id}'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.secondaryLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.quiz_outlined,
                  color: AppColors.secondary, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    quiz.displayTitle,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${quiz.questions.length} سؤال • ${quiz.passPercentage.toInt()}% للنجاح',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 12,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_back_ios,
                color: AppColors.textHint, size: 16),
          ],
        ),
      ),
    );
  }
}

class _CourseDetailShimmer extends StatelessWidget {
  const _CourseDetailShimmer();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[200]!,
      highlightColor: Colors.grey[50]!,
      child: Column(
        children: [
          Container(height: 220, color: Colors.white),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                Container(height: 20, color: Colors.white),
                const SizedBox(height: 12),
                Container(height: 14, color: Colors.white),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
