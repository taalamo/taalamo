import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

import '../../themes/app_colors.dart';
import '../../../data/models/models.dart';

class QuizResultScreen extends StatelessWidget {
  final String quizId;
  final Map<String, dynamic>? extra;

  const QuizResultScreen({
    super.key,
    required this.quizId,
    this.extra,
  });

  @override
  Widget build(BuildContext context) {
    final score = (extra?['score'] as num?)?.toDouble() ?? 0.0;
    final correct = extra?['correct'] as int? ?? 0;
    final total = extra?['total'] as int? ?? 0;
    final passed = extra?['passed'] as bool? ?? false;
    final passPercentage =
        (extra?['passPercentage'] as num?)?.toDouble() ?? 70.0;
    final answers =
        (extra?['answers'] as Map?)?.cast<int, String>() ?? {};
    final questions = (extra?['questions'] as List<QuestionModel>?) ?? [];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),

              // Result Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  gradient: passed
                      ? AppColors.primaryGradient
                      : const LinearGradient(
                          colors: [Color(0xFFE74C3C), Color(0xFFc0392b)],
                        ),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  children: [
                    Text(
                      passed ? '🎉 أحسنت!' : '💪 حاول مرة أخرى',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 24),
                    CircularPercentIndicator(
                      radius: 80,
                      lineWidth: 12,
                      percent: score / 100,
                      center: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${score.toInt()}%',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                          const Text(
                            'النتيجة',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 12,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                      progressColor: Colors.white,
                      backgroundColor: Colors.white.withOpacity(0.3),
                      circularStrokeCap: CircularStrokeCap.round,
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _ResultStat(
                          label: 'صحيح',
                          value: '$correct',
                          icon: Icons.check_circle_outline,
                        ),
                        const SizedBox(width: 32),
                        _ResultStat(
                          label: 'خطأ',
                          value: '${total - correct}',
                          icon: Icons.cancel_outlined,
                        ),
                        const SizedBox(width: 32),
                        _ResultStat(
                          label: 'للنجاح',
                          value: '${passPercentage.toInt()}%',
                          icon: Icons.flag_outlined,
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // Review Answers
              if (questions.isNotEmpty) ...[
                const Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'مراجعة الإجابات',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ...questions.asMap().entries.map(
                  (entry) => _ReviewCard(
                    question: entry.value,
                    index: entry.key + 1,
                    userAnswer: answers[entry.key],
                  ),
                ),
              ],

              const SizedBox(height: 24),

              // Action Buttons
              ElevatedButton.icon(
                onPressed: () => context.pop(),
                icon: const Icon(Icons.arrow_forward_ios, size: 14),
                label: const Text('العودة للكورس',
                    style: TextStyle(fontFamily: 'Cairo')),
              ),
              const SizedBox(height: 12),
              if (!passed)
                OutlinedButton.icon(
                  onPressed: () => context.pop(),
                  icon: const Icon(Icons.refresh, size: 16),
                  label: const Text('إعادة الاختبار',
                      style: TextStyle(fontFamily: 'Cairo')),
                ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _ResultStat({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 22),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: Colors.white,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 12,
            color: Colors.white70,
          ),
        ),
      ],
    );
  }
}

class _ReviewCard extends StatelessWidget {
  final QuestionModel question;
  final int index;
  final String? userAnswer;

  const _ReviewCard({
    required this.question,
    required this.index,
    this.userAnswer,
  });

  @override
  Widget build(BuildContext context) {
    final isCorrect = userAnswer == question.correctAnswer;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isCorrect
              ? AppColors.success.withOpacity(0.4)
              : AppColors.error.withOpacity(0.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: isCorrect
                      ? AppColors.success.withOpacity(0.1)
                      : AppColors.error.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isCorrect ? Icons.check : Icons.close,
                  color: isCorrect ? AppColors.success : AppColors.error,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'سؤال $index',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.w600,
                    color: isCorrect ? AppColors.success : AppColors.error,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            question.questionText,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          if (userAnswer != null)
            _AnswerRow(
              label: 'إجابتك',
              text: userAnswer!,
              isCorrect: isCorrect,
            ),
          if (!isCorrect) ...[
            const SizedBox(height: 6),
            _AnswerRow(
              label: 'الإجابة الصحيحة',
              text: question.correctAnswer,
              isCorrect: true,
            ),
          ],
          if (question.explanation?.isNotEmpty == true) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.accentLight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.lightbulb_outline,
                      color: AppColors.accent, size: 16),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      question.explanation!,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _AnswerRow extends StatelessWidget {
  final String label;
  final String text;
  final bool isCorrect;

  const _AnswerRow({
    required this.label,
    required this.text,
    required this.isCorrect,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$label: ',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: isCorrect ? AppColors.success : AppColors.error,
          ),
        ),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 12,
              color: isCorrect ? AppColors.success : AppColors.error,
            ),
          ),
        ),
      ],
    );
  }
}
