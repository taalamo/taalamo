import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

import '../../themes/app_colors.dart';
import '../../providers/providers.dart';
import '../../../data/models/models.dart';
import '../../../core/services/supabase_service.dart';

class QuizScreen extends ConsumerStatefulWidget {
  final String quizId;

  const QuizScreen({super.key, required this.quizId});

  @override
  ConsumerState<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends ConsumerState<QuizScreen> {
  int _currentQuestion = 0;
  final Map<int, String> _answers = {};
  Timer? _timer;
  int _remainingSeconds = 0;
  bool _submitted = false;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer(int minutes) {
    _remainingSeconds = minutes * 60;
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_remainingSeconds <= 0) {
        t.cancel();
        _submitQuiz(null);
      } else {
        setState(() => _remainingSeconds--);
      }
    });
  }

  String get _timerDisplay {
    final m = _remainingSeconds ~/ 60;
    final s = _remainingSeconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  void _selectAnswer(String answer) {
    setState(() => _answers[_currentQuestion] = answer);
  }

  void _nextQuestion(int total) {
    if (_currentQuestion < total - 1) {
      setState(() => _currentQuestion++);
    }
  }

  void _prevQuestion() {
    if (_currentQuestion > 0) {
      setState(() => _currentQuestion--);
    }
  }

  Future<void> _submitQuiz(QuizModel? quiz) async {
    if (_submitted) return;
    _submitted = true;
    _timer?.cancel();

    if (quiz == null) return;

    int correct = 0;
    for (int i = 0; i < quiz.questions.length; i++) {
      if (_answers[i] == quiz.questions[i].correctAnswer) {
        correct++;
      }
    }

    final score = quiz.questions.isEmpty
        ? 0.0
        : (correct / quiz.questions.length * 100);
    final passed = score >= quiz.passPercentage;

    await supabaseService.submitQuizAttempt(
      quizId: quiz.id,
      score: score,
      totalQuestions: quiz.questions.length,
      correctAnswers: correct,
      passed: passed,
      answers: {
        for (final e in _answers.entries) '${e.key}': e.value,
      },
    );

    if (mounted) {
      context.pushReplacement('/quiz-result/${quiz.id}', extra: {
        'score': score,
        'correct': correct,
        'total': quiz.questions.length,
        'passed': passed,
        'passPercentage': quiz.passPercentage,
        'answers': _answers,
        'questions': quiz.questions,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Find quiz from course quizzes
    // We need to look up the quiz by ID
    return _QuizLoader(
      quizId: widget.quizId,
      onQuizLoaded: (quiz) => _buildQuiz(quiz),
    );
  }

  Widget _buildQuiz(QuizModel quiz) {
    if (quiz.questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('الاختبار',
              style: TextStyle(fontFamily: 'Cairo')),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new),
            onPressed: () => context.pop(),
          ),
        ),
        body: const Center(
          child: Text('لا توجد أسئلة في هذا الاختبار',
              style: TextStyle(fontFamily: 'Cairo')),
        ),
      );
    }

    final q = quiz.questions[_currentQuestion];
    final progress = (_currentQuestion + 1) / quiz.questions.length;
    final hasTimelimit = (quiz.timeLimitMinutes ?? 0) > 0;

    // Start timer once
    if (hasTimelimit && _remainingSeconds == 0) {
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _startTimer(quiz.timeLimitMinutes!),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.textPrimary),
          onPressed: () {
            showDialog(
              context: context,
              builder: (_) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                title: const Text('إنهاء الاختبار؟',
                    style: TextStyle(fontFamily: 'Cairo',
                        fontWeight: FontWeight.w700)),
                content: const Text(
                    'سيتم فقدان إجاباتك الحالية',
                    style: TextStyle(fontFamily: 'Cairo')),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('إلغاء',
                        style: TextStyle(fontFamily: 'Cairo')),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      context.pop();
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.error),
                    child: const Text('خروج',
                        style: TextStyle(fontFamily: 'Cairo')),
                  ),
                ],
              ),
            );
          },
        ),
        title: Text(
          quiz.displayTitle,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          if (hasTimelimit)
            Container(
              margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: _remainingSeconds < 60
                    ? AppColors.error.withOpacity(0.1)
                    : AppColors.primaryLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.timer_outlined,
                    size: 14,
                    color: _remainingSeconds < 60
                        ? AppColors.error
                        : AppColors.primary,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _timerDisplay,
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.w700,
                      color: _remainingSeconds < 60
                          ? AppColors.error
                          : AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Progress
            Row(
              children: [
                Text(
                  'السؤال ${_currentQuestion + 1} من ${quiz.questions.length}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13,
                    color: AppColors.textSecondary,
                  ),
                ),
                const Spacer(),
                Text(
                  '${(_answers.length / quiz.questions.length * 100).toInt()}% تمت الإجابة',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    color: AppColors.textHint,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            LinearPercentIndicator(
              padding: EdgeInsets.zero,
              lineHeight: 8,
              percent: progress,
              progressColor: AppColors.primary,
              backgroundColor: AppColors.primaryLight,
              barRadius: const Radius.circular(4),
            ),
            const SizedBox(height: 28),

            // Question
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Question text
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        q.questionText,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                          height: 1.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Answers
                    if (q.questionType == 'multiple_choice')
                      ...q.options.map(
                        (opt) => _AnswerOption(
                          text: opt,
                          isSelected: _answers[_currentQuestion] == opt,
                          onTap: () => _selectAnswer(opt),
                        ),
                      )
                    else if (q.questionType == 'true_false')
                      ...['صحيح', 'خطأ'].map(
                        (opt) => _AnswerOption(
                          text: opt,
                          isSelected: _answers[_currentQuestion] == opt,
                          onTap: () => _selectAnswer(opt),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            // Navigation
            const SizedBox(height: 16),
            Row(
              children: [
                if (_currentQuestion > 0)
                  OutlinedButton.icon(
                    onPressed: _prevQuestion,
                    icon: const Icon(Icons.arrow_forward_ios, size: 14),
                    label: const Text('السابق',
                        style: TextStyle(fontFamily: 'Cairo')),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(100, 48),
                    ),
                  ),
                const Spacer(),
                if (_currentQuestion < quiz.questions.length - 1)
                  ElevatedButton.icon(
                    onPressed: () => _nextQuestion(quiz.questions.length),
                    icon: const Icon(Icons.arrow_back_ios, size: 14),
                    label: const Text('التالي',
                        style: TextStyle(fontFamily: 'Cairo')),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(120, 48),
                    ),
                  )
                else
                  ElevatedButton.icon(
                    onPressed: _answers.length == quiz.questions.length
                        ? () => _submitQuiz(quiz)
                        : null,
                    icon: const Icon(Icons.check_circle_outline, size: 18),
                    label: const Text('تسليم الاختبار',
                        style: TextStyle(fontFamily: 'Cairo')),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(140, 48),
                      backgroundColor: AppColors.success,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AnswerOption extends StatelessWidget {
  final String text;
  final bool isSelected;
  final VoidCallback onTap;

  const _AnswerOption({
    required this.text,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primarySurface : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? AppColors.primary : Colors.transparent,
                border: Border.all(
                  color: isSelected ? AppColors.primary : AppColors.border,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? const Icon(Icons.check, color: Colors.white, size: 14)
                  : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 15,
                  fontWeight:
                      isSelected ? FontWeight.w600 : FontWeight.w400,
                  color: isSelected
                      ? AppColors.primary
                      : AppColors.textPrimary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Loader widget to find quiz by ID
class _QuizLoader extends ConsumerWidget {
  final String quizId;
  final Widget Function(QuizModel) onQuizLoaded;

  const _QuizLoader({required this.quizId, required this.onQuizLoaded});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder<QuizModel?>(
      future: _loadQuiz(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data == null) {
          return Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new),
                onPressed: () => context.pop(),
              ),
            ),
            body: const Center(
              child: Text('الاختبار غير موجود',
                  style: TextStyle(fontFamily: 'Cairo')),
            ),
          );
        }
        return onQuizLoaded(snapshot.data!);
      },
    );
  }

  Future<QuizModel?> _loadQuiz() async {
    final res = await supabaseService.client
        .from('quizzes')
        .select('*, questions(*)')
        .eq('id', quizId)
        .eq('is_active', true)
        .maybeSingle();

    if (res == null) return null;
    return QuizModel.fromJson(res as Map<String, dynamic>);
  }
}
