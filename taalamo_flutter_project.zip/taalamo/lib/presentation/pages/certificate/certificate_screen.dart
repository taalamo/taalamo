import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';

import '../../themes/app_colors.dart';
import '../../providers/providers.dart';
import '../../../core/services/supabase_service.dart';
import '../../../data/models/models.dart';
import '../../widgets/common/custom_button.dart';
import '../../widgets/common/app_snackbar.dart';

class CertificateScreen extends ConsumerStatefulWidget {
  final String courseId;

  const CertificateScreen({super.key, required this.courseId});

  @override
  ConsumerState<CertificateScreen> createState() => _CertificateScreenState();
}

class _CertificateScreenState extends ConsumerState<CertificateScreen> {
  final _nameCtrl = TextEditingController();
  bool _loading = false;
  CertificateModel? _certificate;
  bool _showForm = true;

  @override
  void initState() {
    super.initState();
    // Pre-fill with user's name
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = ref.read(userProfileProvider).value;
      if (user != null) {
        _nameCtrl.text = user.displayName;
      }
    });
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _generateCertificate() async {
    if (_nameCtrl.text.trim().isEmpty) {
      AppSnackbar.error(context, 'يرجى إدخال الاسم للشهادة');
      return;
    }
    setState(() => _loading = true);
    try {
      final cert = await supabaseService.requestCertificate(
        widget.courseId,
        _nameCtrl.text.trim(),
      );
      if (mounted) {
        setState(() {
          _certificate = cert;
          _showForm = false;
          _loading = false;
        });
        ref.refresh(certificatesProvider);
        AppSnackbar.success(context, 'تم إنشاء شهادتك بنجاح! 🎉');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        AppSnackbar.error(context, 'حدث خطأ في إنشاء الشهادة');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final courseAsync = ref.watch(courseDetailProvider(widget.courseId));

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new,
              color: AppColors.textPrimary),
          onPressed: () => context.pop(),
        ),
        title: const Text(
          'شهادة الإتمام',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: courseAsync.when(
        data: (course) => course == null
            ? const Center(
                child: Text('الكورس غير موجود',
                    style: TextStyle(fontFamily: 'Cairo')))
            : _showForm
                ? _buildForm(course)
                : _buildCertificate(course),
        loading: () =>
            const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(
            child: Text('حدث خطأ', style: TextStyle(fontFamily: 'Cairo'))),
      ),
    );
  }

  Widget _buildForm(CourseModel course) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 20),
          // Illustration
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              gradient: AppColors.goldGradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.accent.withOpacity(0.3),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: const Center(
              child: Icon(Icons.workspace_premium,
                  color: Colors.white, size: 60),
            ),
          ),
          const SizedBox(height: 28),
          Text(
            '🎉 أحسنت!',
            style: Theme.of(context).textTheme.displaySmall,
          ),
          const SizedBox(height: 8),
          Text(
            'أكملت كورس "${course.displayTitle}" بنجاح',
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 15,
              color: AppColors.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          // Name input
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'الاسم الذي سيظهر على الشهادة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _nameCtrl,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  hintText: 'أدخل اسمك هنا',
                  hintStyle: const TextStyle(
                      fontFamily: 'Cairo', color: AppColors.textHint),
                  filled: true,
                  fillColor: AppColors.inputFill,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(
                        color: AppColors.primary, width: 1.5),
                  ),
                  prefixIcon: const Icon(Icons.person_outline,
                      color: AppColors.textHint, size: 20),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'تأكد من صحة اسمك قبل إنشاء الشهادة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: AppColors.textHint,
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          CustomButton(
            text: 'إنشاء الشهادة 🏆',
            onPressed: _generateCertificate,
            isLoading: _loading,
          ),
        ],
      ),
    );
  }

  Widget _buildCertificate(CourseModel course) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 10),
          // Certificate Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFFF8E1), Color(0xFFFFFDE7)],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.accent.withOpacity(0.6),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.accent.withOpacity(0.2),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              children: [
                // Header decoration
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text('⭐', style: TextStyle(fontSize: 20)),
                    SizedBox(width: 8),
                    Text('⭐', style: TextStyle(fontSize: 24)),
                    SizedBox(width: 8),
                    Text('⭐', style: TextStyle(fontSize: 20)),
                  ],
                ),
                const SizedBox(height: 16),

                // Trophy
                const Text('🏆', style: TextStyle(fontSize: 52)),
                const SizedBox(height: 16),

                // Title
                Text(
                  'شهادة إتمام',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'CERTIFICATE OF COMPLETION',
                  style: TextStyle(
                    fontSize: 10,
                    color: AppColors.textHint,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(height: 20),

                // Divider
                Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        AppColors.accent,
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Recipient name
                const Text(
                  'يُشهد بأن',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 14,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  _certificate?.displayName ?? _nameCtrl.text.trim(),
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textPrimary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                const Text(
                  'قد أتمّ بنجاح كورس',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 14,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  course.displayTitle,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        AppColors.accent,
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Date
                Text(
                  'تاريخ الإصدار: ${_formatDate(DateTime.now())}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'تعلّمو | OmniLearn',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Action buttons
          ElevatedButton.icon(
            onPressed: () => _share(course),
            icon: const Icon(Icons.share_outlined, size: 18),
            label: const Text('مشاركة الشهادة',
                style: TextStyle(fontFamily: 'Cairo')),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => context.go('/home'),
            icon: const Icon(Icons.home_outlined, size: 18),
            label: const Text('الصفحة الرئيسية',
                style: TextStyle(fontFamily: 'Cairo')),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  void _share(CourseModel course) {
    final name = _certificate?.displayName ?? _nameCtrl.text.trim();
    Share.share(
      'حصلت على شهادة إتمام كورس "${course.displayTitle}" من منصة تعلّمو! 🏆\n\nاسم المتعلم: $name',
      subject: 'شهادة إتمام - ${course.displayTitle}',
    );
  }

  String _formatDate(DateTime d) {
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
    ];
    return '${d.day} ${months[d.month - 1]} ${d.year}';
  }
}
