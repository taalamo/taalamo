import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../themes/app_colors.dart';
import '../../providers/providers.dart';
import '../../../core/services/supabase_service.dart';
import '../../../data/models/models.dart';
import '../../widgets/common/app_snackbar.dart';

class LessonScreen extends ConsumerStatefulWidget {
  final String courseId;
  final String lessonId;

  const LessonScreen({
    super.key,
    required this.courseId,
    required this.lessonId,
  });

  @override
  ConsumerState<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends ConsumerState<LessonScreen> {
  YoutubePlayerController? _ytController;
  LessonModel? _currentLesson;
  List<LessonModel> _lessons = [];
  int _currentIndex = 0;
  bool _isCompleted = false;

  @override
  void initState() {
    super.initState();
    _loadLesson();
  }

  Future<void> _loadLesson() async {
    final lessons = await supabaseService.getCourseLessons(widget.courseId);
    if (!mounted) return;
    setState(() {
      _lessons = lessons;
      _currentIndex =
          lessons.indexWhere((l) => l.id == widget.lessonId);
      if (_currentIndex == -1) _currentIndex = 0;
      _currentLesson = lessons.isNotEmpty ? lessons[_currentIndex] : null;
      _isCompleted = _currentLesson?.isCompleted ?? false;
    });
    _initPlayer();
  }

  void _initPlayer() {
    _ytController?.dispose();
    final videoId = _currentLesson?.youtubeVideoId;
    if (videoId == null || videoId.isEmpty) return;

    _ytController = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: true,
        captionLanguage: 'ar',
      ),
    );
    _ytController!.addListener(_onPlayerStateChange);
    if (mounted) setState(() {});
  }

  void _onPlayerStateChange() {
    if (_ytController == null) return;
    final pos = _ytController!.value.position;
    final dur = _ytController!.metadata.duration;

    if (dur.inSeconds > 0) {
      final watched = pos.inSeconds / dur.inSeconds;
      if (watched >= 0.9 && !_isCompleted) {
        _markComplete();
      }
    }
  }

  Future<void> _markComplete() async {
    if (_isCompleted || _currentLesson == null) return;
    setState(() => _isCompleted = true);
    await supabaseService.updateLessonProgress(
      widget.courseId,
      _currentLesson!.id,
      true,
    );
    ref.refresh(courseLessonsProvider(widget.courseId));
    ref.refresh(courseDetailProvider(widget.courseId));
    if (mounted) AppSnackbar.success(context, '✅ تم إكمال الدرس!');
  }

  void _goToLesson(int index) {
    if (index < 0 || index >= _lessons.length) return;
    setState(() {
      _currentIndex = index;
      _currentLesson = _lessons[index];
      _isCompleted = _currentLesson?.isCompleted ?? false;
    });
    _initPlayer();
  }

  @override
  void dispose() {
    _ytController?.removeListener(_onPlayerStateChange);
    _ytController?.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayerBuilder(
      player: YoutubePlayer(
        controller: _ytController ??
            YoutubePlayerController(
              initialVideoId: '',
              flags: const YoutubePlayerFlags(autoPlay: false),
            ),
        showVideoProgressIndicator: true,
        progressIndicatorColor: AppColors.primary,
        onEnded: (_) {
          _markComplete();
          // Auto-play next lesson
          if (_currentIndex < _lessons.length - 1) {
            Future.delayed(const Duration(seconds: 2), () {
              if (mounted) _goToLesson(_currentIndex + 1);
            });
          }
        },
      ),
      builder: (context, player) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new,
                color: AppColors.textPrimary),
            onPressed: () => context.pop(),
          ),
          title: Text(
            _currentLesson?.displayTitle ?? 'الدرس',
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          actions: [
            if (_isCompleted)
              const Padding(
                padding: EdgeInsets.all(12),
                child: Icon(Icons.check_circle,
                    color: AppColors.primary, size: 22),
              ),
          ],
        ),
        body: Column(
          children: [
            // ─── Video Player ──────────────────────────────────
            player,

            // ─── Lesson Info ───────────────────────────────────
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title & status
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _currentLesson?.displayTitle ?? '',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                        if (_isCompleted)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.primaryLight,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.check_circle,
                                    color: AppColors.primary, size: 14),
                                SizedBox(width: 4),
                                Text(
                                  'مكتمل',
                                  style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 12,
                                    color: AppColors.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),

                    if (_currentLesson?.description?.isNotEmpty == true) ...[
                      const SizedBox(height: 12),
                      Text(
                        _currentLesson!.description!,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 14,
                          color: AppColors.textSecondary,
                          height: 1.6,
                        ),
                      ),
                    ],

                    if (_currentLesson?.notes?.isNotEmpty == true) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.accentLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: AppColors.accent.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Row(
                              children: [
                                Icon(Icons.lightbulb_outline,
                                    color: AppColors.accent, size: 18),
                                SizedBox(width: 6),
                                Text(
                                  'ملاحظات',
                                  style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.accent,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _currentLesson!.notes!,
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 13,
                                color: AppColors.textPrimary,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    const SizedBox(height: 24),

                    // Navigation buttons
                    Row(
                      children: [
                        if (_currentIndex > 0)
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () =>
                                  _goToLesson(_currentIndex - 1),
                              icon: const Icon(Icons.arrow_forward_ios,
                                  size: 14),
                              label: const Text('السابق',
                                  style: TextStyle(fontFamily: 'Cairo')),
                              style: OutlinedButton.styleFrom(
                                minimumSize: const Size(0, 44),
                              ),
                            ),
                          ),
                        if (_currentIndex > 0 &&
                            _currentIndex < _lessons.length - 1)
                          const SizedBox(width: 12),
                        if (_currentIndex < _lessons.length - 1)
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () =>
                                  _goToLesson(_currentIndex + 1),
                              icon: const Icon(Icons.arrow_back_ios,
                                  size: 14),
                              label: const Text('التالي',
                                  style: TextStyle(fontFamily: 'Cairo')),
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size(0, 44),
                              ),
                            ),
                          ),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // Lessons list
                    const Text(
                      'قائمة الدروس',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._lessons.asMap().entries.map(
                      (entry) => _LessonListItem(
                        lesson: entry.value,
                        index: entry.key + 1,
                        isCurrent: entry.key == _currentIndex,
                        onTap: () => _goToLesson(entry.key),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LessonListItem extends StatelessWidget {
  final LessonModel lesson;
  final int index;
  final bool isCurrent;
  final VoidCallback onTap;

  const _LessonListItem({
    required this.lesson,
    required this.index,
    required this.isCurrent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isCompleted = lesson.isCompleted ?? false;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isCurrent
              ? AppColors.primarySurface
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isCurrent
                ? AppColors.primary.withOpacity(0.3)
                : Colors.transparent,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: isCompleted
                    ? AppColors.primary
                    : isCurrent
                        ? AppColors.primaryLight
                        : AppColors.inputFill,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: isCompleted
                    ? const Icon(Icons.check,
                        color: Colors.white, size: 15)
                    : isCurrent
                        ? const Icon(Icons.play_arrow,
                            color: AppColors.primary, size: 16)
                        : Text(
                            '$index',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary,
                            ),
                          ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                lesson.displayTitle,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 13,
                  fontWeight:
                      isCurrent ? FontWeight.w600 : FontWeight.w400,
                  color: isCurrent
                      ? AppColors.primary
                      : AppColors.textPrimary,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text(
              lesson.durationFormatted,
              style: const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 11,
                color: AppColors.textHint,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
