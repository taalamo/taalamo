import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/services/supabase_service.dart';
import '../data/models/models.dart';

// ─── Supabase Service Provider ────────────────────────────────────────────────
final supabaseServiceProvider = Provider<SupabaseService>((ref) {
  return supabaseService;
});

// ─── Auth State Provider ──────────────────────────────────────────────────────
final authStateProvider = StreamProvider<AuthState>((ref) {
  return Supabase.instance.client.auth.onAuthStateChange;
});

final currentUserIdProvider = Provider<String?>((ref) {
  return Supabase.instance.client.auth.currentUser?.id;
});

final isLoggedInProvider = Provider<bool>((ref) {
  return Supabase.instance.client.auth.currentUser != null;
});

// ─── User Profile Provider ────────────────────────────────────────────────────
final userProfileProvider =
    FutureProvider.autoDispose<UserModel?>((ref) async {
  final userId = ref.watch(currentUserIdProvider);
  if (userId == null) return null;
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getUserProfile(userId);
});

// ─── Categories Provider ──────────────────────────────────────────────────────
final categoriesProvider =
    FutureProvider.autoDispose<List<CategoryModel>>((ref) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getCategories();
});

// ─── Selected Category Provider ───────────────────────────────────────────────
final selectedCategoryProvider = StateProvider<String?>((ref) => null);

// ─── Featured Courses Provider ────────────────────────────────────────────────
final featuredCoursesProvider =
    FutureProvider.autoDispose<List<CourseModel>>((ref) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getCourses(isFeatured: true, limit: 6);
});

// ─── All Courses Provider (with filter) ──────────────────────────────────────
final coursesFilterProvider = StateProvider<CourseFilter>((ref) {
  return const CourseFilter();
});

final coursesProvider =
    FutureProvider.autoDispose<List<CourseModel>>((ref) async {
  final filter = ref.watch(coursesFilterProvider);
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getCourses(
    categoryId: filter.categoryId,
    level: filter.level,
    search: filter.search,
    limit: 20,
  );
});

// ─── Enrolled Courses Provider ────────────────────────────────────────────────
final enrolledCoursesProvider =
    FutureProvider.autoDispose<List<CourseModel>>((ref) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getEnrolledCourses();
});

// ─── Course Detail Provider ───────────────────────────────────────────────────
final courseDetailProvider =
    FutureProvider.autoDispose.family<CourseModel?, String>((ref, id) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getCourseById(id);
});

// ─── Course Lessons Provider ──────────────────────────────────────────────────
final courseLessonsProvider =
    FutureProvider.autoDispose.family<List<LessonModel>, String>(
        (ref, courseId) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getCourseLessons(courseId);
});

// ─── Quiz Provider ────────────────────────────────────────────────────────────
final courseQuizzesProvider =
    FutureProvider.autoDispose.family<List<QuizModel>, String>(
        (ref, courseId) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getCourseQuizzes(courseId);
});

// ─── Certificates Provider ────────────────────────────────────────────────────
final certificatesProvider =
    FutureProvider.autoDispose<List<CertificateModel>>((ref) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getUserCertificates();
});

// ─── Badges Provider ──────────────────────────────────────────────────────────
final badgesProvider =
    FutureProvider.autoDispose<List<BadgeModel>>((ref) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getUserBadges();
});

// ─── Notifications Provider ───────────────────────────────────────────────────
final notificationsProvider =
    FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.getNotifications();
});

// ─── Course Saved Status Provider ─────────────────────────────────────────────
final courseSavedProvider =
    FutureProvider.autoDispose.family<bool, String>((ref, courseId) async {
  final svc = ref.read(supabaseServiceProvider);
  return await svc.isCourseSaved(courseId);
});

// ─── Filter Model ─────────────────────────────────────────────────────────────
class CourseFilter {
  final String? categoryId;
  final String? level;
  final String? search;

  const CourseFilter({this.categoryId, this.level, this.search});

  CourseFilter copyWith({
    String? categoryId,
    String? level,
    String? search,
  }) {
    return CourseFilter(
      categoryId: categoryId ?? this.categoryId,
      level: level ?? this.level,
      search: search ?? this.search,
    );
  }
}
