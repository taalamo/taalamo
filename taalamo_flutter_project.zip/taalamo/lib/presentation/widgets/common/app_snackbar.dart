import 'package:flutter/material.dart';

class AppSnackbar {
  static void show(
    BuildContext context,
    String message, {
    Color backgroundColor = const Color(0xFF1A2E22),
    IconData? icon,
  }) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            if (icon != null) ...[
              Icon(icon, color: Colors.white, size: 20),
              const SizedBox(width: 10),
            ],
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 14,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: backgroundColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  static void success(BuildContext context, String message) {
    show(context, message,
        backgroundColor: const Color(0xFF27AE60),
        icon: Icons.check_circle_outline);
  }

  static void error(BuildContext context, String message) {
    show(context, message,
        backgroundColor: const Color(0xFFE74C3C),
        icon: Icons.error_outline);
  }

  static void info(BuildContext context, String message) {
    show(context, message,
        backgroundColor: const Color(0xFF3498DB),
        icon: Icons.info_outline);
  }

  static void warning(BuildContext context, String message) {
    show(context, message,
        backgroundColor: const Color(0xFFF39C12),
        icon: Icons.warning_amber_outlined);
  }
}
