import 'package:flutter/material.dart';

class AppColors {
  // ─── Primary ───────────────────────────────────────────────────
  static const Color primary = Color(0xFF2ECC71);        // أخضر حيوي
  static const Color primaryDark = Color(0xFF27AE60);
  static const Color primaryLight = Color(0xFFD5F5E3);
  static const Color primarySurface = Color(0xFFF0FBF4);

  // ─── Secondary ─────────────────────────────────────────────────
  static const Color secondary = Color(0xFF3498DB);       // أزرق
  static const Color secondaryDark = Color(0xFF2980B9);
  static const Color secondaryLight = Color(0xFFD6EAF8);

  // ─── Accent ────────────────────────────────────────────────────
  static const Color accent = Color(0xFFF39C12);          // برتقالي ذهبي
  static const Color accentLight = Color(0xFFFEF9E7);

  // ─── Backgrounds ───────────────────────────────────────────────
  static const Color background = Color(0xFFF8FAF9);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color inputFill = Color(0xFFF2F6F4);
  static const Color darkBackground = Color(0xFF0D1117);
  static const Color darkSurface = Color(0xFF161B22);

  // ─── Text ──────────────────────────────────────────────────────
  static const Color textPrimary = Color(0xFF1A2E22);
  static const Color textSecondary = Color(0xFF5A7B68);
  static const Color textHint = Color(0xFF9DB8A8);
  static const Color textInverse = Color(0xFFFFFFFF);

  // ─── Status ────────────────────────────────────────────────────
  static const Color success = Color(0xFF27AE60);
  static const Color error = Color(0xFFE74C3C);
  static const Color warning = Color(0xFFF39C12);
  static const Color info = Color(0xFF3498DB);

  // ─── Gamification ──────────────────────────────────────────────
  static const Color xpGold = Color(0xFFFFD700);
  static const Color badgeSilver = Color(0xFFC0C0C0);
  static const Color badgeBronze = Color(0xFFCD7F32);
  static const Color streakFire = Color(0xFFFF6B35);

  // ─── Levels ────────────────────────────────────────────────────
  static const Color levelBeginner = Color(0xFF27AE60);
  static const Color levelIntermediate = Color(0xFFF39C12);
  static const Color levelAdvanced = Color(0xFFE74C3C);

  // ─── Category Colors ───────────────────────────────────────────
  static const Color catProgramming = Color(0xFF6C5CE7);
  static const Color catLanguages = Color(0xFF00B894);
  static const Color catCooking = Color(0xFFE17055);
  static const Color catDesign = Color(0xFFE84393);
  static const Color catAI = Color(0xFF0984E3);
  static const Color catBusiness = Color(0xFFFFB347);

  // ─── Borders & Dividers ────────────────────────────────────────
  static const Color border = Color(0xFFDCEDE5);
  static const Color divider = Color(0xFFF0F4F2);

  // ─── Shadows ───────────────────────────────────────────────────
  static const Color shadowLight = Color(0x0A000000);
  static const Color shadowMedium = Color(0x1A000000);

  // ─── Gradient Presets ──────────────────────────────────────────
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF2ECC71), Color(0xFF27AE60)],
  );

  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF1A2E22), Color(0xFF2ECC71)],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
  );

  static BoxDecoration cardShadow = BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(16),
    boxShadow: [
      BoxShadow(
        color: AppColors.shadowLight,
        blurRadius: 12,
        offset: const Offset(0, 4),
      ),
    ],
  );

  static BoxDecoration elevatedCardShadow = BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(20),
    boxShadow: [
      BoxShadow(
        color: AppColors.shadowMedium,
        blurRadius: 20,
        offset: const Offset(0, 8),
      ),
    ],
  );
}
