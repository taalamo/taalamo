// ─── Course Model ─────────────────────────────────────────────────────────────
class CourseModel {
  final String id;
  final String title;
  final String? titleAr;
  final String? description;
  final String? descriptionAr;
  final String? thumbnailUrl;
  final String? categoryId;
  final String level;
  final String language;
  final String? youtubePlaylistId;
  final String? youtubePlaylistUrl;
  final int totalLessons;
  final int totalDurationMinutes;
  final bool isActive;
  final bool isFeatured;
  final bool isFree;
  final List<String> tags;
  final String? createdBy;
  final DateTime? createdAt;
  final double avgRating;
  final int totalRatings;
  // Joined data
  final CategoryModel? category;
  final double? completionPercentage;
  final bool? isEnrolled;

  const CourseModel({
    required this.id,
    required this.title,
    this.titleAr,
    this.description,
    this.descriptionAr,
    this.thumbnailUrl,
    this.categoryId,
    this.level = 'beginner',
    this.language = 'ar',
    this.youtubePlaylistId,
    this.youtubePlaylistUrl,
    this.totalLessons = 0,
    this.totalDurationMinutes = 0,
    this.isActive = true,
    this.isFeatured = false,
    this.isFree = true,
    this.tags = const [],
    this.createdBy,
    this.createdAt,
    this.avgRating = 0.0,
    this.totalRatings = 0,
    this.category,
    this.completionPercentage,
    this.isEnrolled,
  });

  String get displayTitle => titleAr ?? title;
  String get displayDescription => descriptionAr ?? description ?? '';

  factory CourseModel.fromJson(Map<String, dynamic> json) {
    return CourseModel(
      id: json['id'] as String,
      title: json['title'] as String,
      titleAr: json['title_ar'] as String?,
      description: json['description'] as String?,
      descriptionAr: json['description_ar'] as String?,
      thumbnailUrl: json['thumbnail_url'] as String?,
      categoryId: json['category_id'] as String?,
      level: json['level'] as String? ?? 'beginner',
      language: json['language'] as String? ?? 'ar',
      youtubePlaylistId: json['youtube_playlist_id'] as String?,
      youtubePlaylistUrl: json['youtube_playlist_url'] as String?,
      totalLessons: json['total_lessons'] as int? ?? 0,
      totalDurationMinutes: json['total_duration_minutes'] as int? ?? 0,
      isActive: json['is_active'] as bool? ?? true,
      isFeatured: json['is_featured'] as bool? ?? false,
      isFree: json['is_free'] as bool? ?? true,
      tags: (json['tags'] as List<dynamic>?)?.cast<String>() ?? [],
      createdBy: json['created_by'] as String?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : null,
      avgRating: (json['avg_rating'] as num?)?.toDouble() ?? 0.0,
      totalRatings: json['total_ratings'] as int? ?? 0,
      category: json['categories'] != null
          ? CategoryModel.fromJson(json['categories'] as Map<String, dynamic>)
          : null,
      completionPercentage:
          (json['completion_percentage'] as num?)?.toDouble(),
      isEnrolled: json['is_enrolled'] as bool?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'title_ar': titleAr,
        'description': description,
        'description_ar': descriptionAr,
        'thumbnail_url': thumbnailUrl,
        'category_id': categoryId,
        'level': level,
        'language': language,
        'youtube_playlist_id': youtubePlaylistId,
        'youtube_playlist_url': youtubePlaylistUrl,
        'total_lessons': totalLessons,
        'total_duration_minutes': totalDurationMinutes,
        'is_active': isActive,
        'is_featured': isFeatured,
        'is_free': isFree,
        'tags': tags,
      };
}

// ─── Lesson Model ─────────────────────────────────────────────────────────────
class LessonModel {
  final String id;
  final String? moduleId;
  final String courseId;
  final String title;
  final String? titleAr;
  final String? description;
  final String? videoUrl;
  final String? youtubeVideoId;
  final int durationSeconds;
  final String? thumbnailUrl;
  final int orderIndex;
  final bool isActive;
  final bool isFreePreview;
  final String? notes;
  final bool? isCompleted;

  const LessonModel({
    required this.id,
    this.moduleId,
    required this.courseId,
    required this.title,
    this.titleAr,
    this.description,
    this.videoUrl,
    this.youtubeVideoId,
    this.durationSeconds = 0,
    this.thumbnailUrl,
    this.orderIndex = 0,
    this.isActive = true,
    this.isFreePreview = false,
    this.notes,
    this.isCompleted,
  });

  String get displayTitle => titleAr ?? title;
  String get durationFormatted {
    final m = durationSeconds ~/ 60;
    final s = durationSeconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  factory LessonModel.fromJson(Map<String, dynamic> json) {
    return LessonModel(
      id: json['id'] as String,
      moduleId: json['module_id'] as String?,
      courseId: json['course_id'] as String,
      title: json['title'] as String,
      titleAr: json['title_ar'] as String?,
      description: json['description'] as String?,
      videoUrl: json['video_url'] as String?,
      youtubeVideoId: json['youtube_video_id'] as String?,
      durationSeconds: json['duration_seconds'] as int? ?? 0,
      thumbnailUrl: json['thumbnail_url'] as String?,
      orderIndex: json['order_index'] as int? ?? 0,
      isActive: json['is_active'] as bool? ?? true,
      isFreePreview: json['is_free_preview'] as bool? ?? false,
      notes: json['notes'] as String?,
      isCompleted: json['is_completed'] as bool?,
    );
  }
}

// ─── User Model ───────────────────────────────────────────────────────────────
class UserModel {
  final String id;
  final String? email;
  final String? fullName;
  final String? avatarUrl;
  final String? bio;
  final List<String> interests;
  final int totalXp;
  final int level;
  final int streakDays;
  final bool isPremium;
  final DateTime? premiumExpiresAt;
  final String preferredLanguage;
  final bool darkModeEnabled;
  final bool notificationsEnabled;
  final DateTime? createdAt;
  final DateTime? lastActiveDate;

  const UserModel({
    required this.id,
    this.email,
    this.fullName,
    this.avatarUrl,
    this.bio,
    this.interests = const [],
    this.totalXp = 0,
    this.level = 1,
    this.streakDays = 0,
    this.isPremium = false,
    this.premiumExpiresAt,
    this.preferredLanguage = 'ar',
    this.darkModeEnabled = false,
    this.notificationsEnabled = true,
    this.createdAt,
    this.lastActiveDate,
  });

  String get displayName => fullName ?? email?.split('@').first ?? 'مستخدم';

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      email: json['email'] as String?,
      fullName: json['full_name'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      bio: json['bio'] as String?,
      interests:
          (json['interests'] as List<dynamic>?)?.cast<String>() ?? [],
      totalXp: json['total_xp'] as int? ?? 0,
      level: json['level'] as int? ?? 1,
      streakDays: json['streak_days'] as int? ?? 0,
      isPremium: json['is_premium'] as bool? ?? false,
      premiumExpiresAt: json['premium_expires_at'] != null
          ? DateTime.parse(json['premium_expires_at'] as String)
          : null,
      preferredLanguage: json['preferred_language'] as String? ?? 'ar',
      darkModeEnabled: json['dark_mode_enabled'] as bool? ?? false,
      notificationsEnabled: json['notifications_enabled'] as bool? ?? true,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'full_name': fullName,
        'avatar_url': avatarUrl,
        'bio': bio,
        'interests': interests,
        'total_xp': totalXp,
        'level': level,
        'streak_days': streakDays,
        'is_premium': isPremium,
        'preferred_language': preferredLanguage,
        'dark_mode_enabled': darkModeEnabled,
        'notifications_enabled': notificationsEnabled,
      };
}

// ─── Category Model ───────────────────────────────────────────────────────────
class CategoryModel {
  final String id;
  final String name;
  final String? nameAr;
  final String? description;
  final String? iconUrl;
  final String colorHex;
  final bool isActive;

  const CategoryModel({
    required this.id,
    required this.name,
    this.nameAr,
    this.description,
    this.iconUrl,
    this.colorHex = '#4CAF50',
    this.isActive = true,
  });

  String get displayName => nameAr ?? name;

  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['id'] as String,
      name: json['name'] as String,
      nameAr: json['name_ar'] as String?,
      description: json['description'] as String?,
      iconUrl: json['icon_url'] as String?,
      colorHex: json['color_hex'] as String? ?? '#4CAF50',
      isActive: json['is_active'] as bool? ?? true,
    );
  }
}

// ─── Quiz Model ───────────────────────────────────────────────────────────────
class QuizModel {
  final String id;
  final String courseId;
  final String? moduleId;
  final String? lessonId;
  final String title;
  final String? titleAr;
  final String? description;
  final double passPercentage;
  final int? timeLimitMinutes;
  final int maxAttempts;
  final bool isActive;
  final List<QuestionModel> questions;

  const QuizModel({
    required this.id,
    required this.courseId,
    this.moduleId,
    this.lessonId,
    required this.title,
    this.titleAr,
    this.description,
    this.passPercentage = 70.0,
    this.timeLimitMinutes,
    this.maxAttempts = 3,
    this.isActive = true,
    this.questions = const [],
  });

  String get displayTitle => titleAr ?? title;

  factory QuizModel.fromJson(Map<String, dynamic> json) {
    return QuizModel(
      id: json['id'] as String,
      courseId: json['course_id'] as String,
      moduleId: json['module_id'] as String?,
      lessonId: json['lesson_id'] as String?,
      title: json['title'] as String,
      titleAr: json['title_ar'] as String?,
      description: json['description'] as String?,
      passPercentage:
          (json['pass_percentage'] as num?)?.toDouble() ?? 70.0,
      timeLimitMinutes: json['time_limit_minutes'] as int?,
      maxAttempts: json['max_attempts'] as int? ?? 3,
      isActive: json['is_active'] as bool? ?? true,
      questions: (json['questions'] as List<dynamic>?)
              ?.map((q) =>
                  QuestionModel.fromJson(q as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }
}

// ─── Question Model ───────────────────────────────────────────────────────────
class QuestionModel {
  final String id;
  final String quizId;
  final String questionText;
  final String questionType;
  final List<String> options;
  final String correctAnswer;
  final String? explanation;
  final int orderIndex;

  const QuestionModel({
    required this.id,
    required this.quizId,
    required this.questionText,
    this.questionType = 'multiple_choice',
    this.options = const [],
    required this.correctAnswer,
    this.explanation,
    this.orderIndex = 0,
  });

  factory QuestionModel.fromJson(Map<String, dynamic> json) {
    return QuestionModel(
      id: json['id'] as String,
      quizId: json['quiz_id'] as String,
      questionText: json['question_text'] as String,
      questionType: json['question_type'] as String? ?? 'multiple_choice',
      options: (json['options'] as List<dynamic>?)?.cast<String>() ?? [],
      correctAnswer: json['correct_answer'] as String,
      explanation: json['explanation'] as String?,
      orderIndex: json['order_index'] as int? ?? 0,
    );
  }
}

// ─── Certificate Model ────────────────────────────────────────────────────────
class CertificateModel {
  final String id;
  final String userId;
  final String courseId;
  final String displayName;
  final String? certificateUrl;
  final DateTime? issuedAt;
  final CourseModel? course;

  const CertificateModel({
    required this.id,
    required this.userId,
    required this.courseId,
    required this.displayName,
    this.certificateUrl,
    this.issuedAt,
    this.course,
  });

  factory CertificateModel.fromJson(Map<String, dynamic> json) {
    return CertificateModel(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      courseId: json['course_id'] as String,
      displayName: json['display_name'] as String,
      certificateUrl: json['certificate_url'] as String?,
      issuedAt: json['issued_at'] != null
          ? DateTime.parse(json['issued_at'] as String)
          : null,
      course: json['courses'] != null
          ? CourseModel.fromJson(json['courses'] as Map<String, dynamic>)
          : null,
    );
  }
}

// ─── Badge Model ──────────────────────────────────────────────────────────────
class BadgeModel {
  final String id;
  final String name;
  final String? nameAr;
  final String? description;
  final String? descriptionAr;
  final String? iconUrl;
  final String colorHex;
  final String badgeType;
  final int conditionValue;
  final int xpReward;
  final DateTime? earnedAt;

  const BadgeModel({
    required this.id,
    required this.name,
    this.nameAr,
    this.description,
    this.descriptionAr,
    this.iconUrl,
    this.colorHex = '#FFD700',
    this.badgeType = 'course_completion',
    this.conditionValue = 1,
    this.xpReward = 50,
    this.earnedAt,
  });

  String get displayName => nameAr ?? name;
  String get displayDescription => descriptionAr ?? description ?? '';

  factory BadgeModel.fromJson(Map<String, dynamic> json) {
    return BadgeModel(
      id: json['id'] as String,
      name: json['name'] as String,
      nameAr: json['name_ar'] as String?,
      description: json['description'] as String?,
      descriptionAr: json['description_ar'] as String?,
      iconUrl: json['icon_url'] as String?,
      colorHex: json['color_hex'] as String? ?? '#FFD700',
      badgeType: json['badge_type'] as String? ?? 'course_completion',
      conditionValue: json['condition_value'] as int? ?? 1,
      xpReward: json['xp_reward'] as int? ?? 50,
      earnedAt: json['earned_at'] != null
          ? DateTime.parse(json['earned_at'] as String)
          : null,
    );
  }
}
