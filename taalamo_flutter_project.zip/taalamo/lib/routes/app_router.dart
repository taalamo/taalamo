import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../presentation/pages/splash/splash_screen.dart';
import '../presentation/pages/onboarding/onboarding_screen.dart';
import '../presentation/pages/auth/login_screen.dart';
import '../presentation/pages/auth/register_screen.dart';
import '../presentation/pages/auth/interests_screen.dart';
import '../presentation/pages/home/home_screen.dart';
import '../presentation/pages/courses/courses_screen.dart';
import '../presentation/pages/courses/course_detail_screen.dart';
import '../presentation/pages/lesson/lesson_screen.dart';
import '../presentation/pages/quiz/quiz_screen.dart';
import '../presentation/pages/quiz/quiz_result_screen.dart';
import '../presentation/pages/profile/profile_screen.dart';
import '../presentation/pages/search/search_screen.dart';
import '../presentation/pages/certificate/certificate_screen.dart';
import '../presentation/pages/main/main_shell.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/splash',
    redirect: (context, state) {
      final user = Supabase.instance.client.auth.currentUser;
      final isAuth = user != null;
      final isSplash = state.matchedLocation == '/splash';
      final isOnboarding = state.matchedLocation == '/onboarding';
      final isAuthPage = state.matchedLocation.startsWith('/auth');

      if (isSplash || isOnboarding) return null;
      if (!isAuth && !isAuthPage) return '/auth/login';
      if (isAuth && isAuthPage) return '/home';
      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        builder: (_, __) => const SplashScreen(),
      ),
      GoRoute(
        path: '/onboarding',
        builder: (_, __) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/auth/login',
        builder: (_, __) => const LoginScreen(),
      ),
      GoRoute(
        path: '/auth/register',
        builder: (_, __) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/auth/interests',
        builder: (_, __) => const InterestsScreen(),
      ),
      // ─── Main Shell with Bottom Nav ─────────────────────────────
      ShellRoute(
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          GoRoute(
            path: '/home',
            builder: (_, __) => const HomeScreen(),
          ),
          GoRoute(
            path: '/courses',
            builder: (_, __) => const CoursesScreen(),
          ),
          GoRoute(
            path: '/search',
            builder: (_, __) => const SearchScreen(),
          ),
          GoRoute(
            path: '/profile',
            builder: (_, __) => const ProfileScreen(),
          ),
        ],
      ),
      // ─── Standalone Pages ───────────────────────────────────────
      GoRoute(
        path: '/course/:id',
        builder: (_, state) => CourseDetailScreen(
          courseId: state.pathParameters['id']!,
        ),
      ),
      GoRoute(
        path: '/lesson/:courseId/:lessonId',
        builder: (_, state) => LessonScreen(
          courseId: state.pathParameters['courseId']!,
          lessonId: state.pathParameters['lessonId']!,
        ),
      ),
      GoRoute(
        path: '/quiz/:quizId',
        builder: (_, state) => QuizScreen(
          quizId: state.pathParameters['quizId']!,
        ),
      ),
      GoRoute(
        path: '/quiz-result/:quizId',
        builder: (_, state) => QuizResultScreen(
          quizId: state.pathParameters['quizId']!,
          extra: state.extra as Map<String, dynamic>?,
        ),
      ),
      GoRoute(
        path: '/certificate/:courseId',
        builder: (_, state) => CertificateScreen(
          courseId: state.pathParameters['courseId']!,
        ),
      ),
    ],
  );
});
