# تعلّمو - OmniLearn Flutter App

تطبيق تعليمي شامل مبني بـ Flutter + Supabase.

---

## 📋 متطلبات التشغيل

- Flutter SDK 3.x أو أحدث
- Dart SDK 3.x
- Android Studio / VS Code
- حساب Supabase (موجود ومربوط)
- حساب Firebase (للإشعارات)

---

## 🚀 خطوات الإعداد

### 1. استخراج الملفات
```bash
unzip taalamo.zip -d taalamo
cd taalamo
```

### 2. تثبيت المكتبات
```bash
flutter pub get
```

### 3. إعداد Firebase
1. اذهب إلى [Firebase Console](https://console.firebase.google.com)
2. أنشئ مشروعاً باسم `taalamo-app`
3. أضف تطبيق Android بـ package name: `com.taalamo.app`
4. نزّل `google-services.json` وضعه في `android/app/`
5. فعّل Firebase Messaging و Firebase Analytics

### 4. إعداد Google OAuth
1. في Firebase Console → Authentication → Sign-in method
2. فعّل Google
3. انسخ Web Client ID
4. اذهب إلى Supabase Dashboard → Authentication → Providers → Google
5. أضف Client ID و Client Secret

### 5. تشغيل Migration SQL
في Supabase SQL Editor، شغّل ملف:
```
supabase/migrations/001_functions.sql
```

### 6. نشر Edge Functions
```bash
supabase functions deploy fetch-youtube-playlist
supabase functions deploy generate-quiz
```

أضف Secrets في Supabase Dashboard:
```
YOUTUBE_API_KEY=your_youtube_api_key
GEMINI_API_KEY=your_gemini_api_key
```

### 7. تشغيل التطبيق
```bash
flutter run
```

### 8. بناء APK للنشر
```bash
flutter build apk --release --split-per-abi
# أو
flutter build appbundle --release
```

---

## 🏗️ هيكل المشروع

```
lib/
├── main.dart                    # نقطة الدخول
├── app.dart                     # MaterialApp + Theme
├── core/
│   ├── constants/
│   │   ├── app_constants.dart   # Supabase URL, Keys, XP thresholds
│   │   └── app_strings.dart     # نصوص UI العربية
│   ├── services/
│   │   ├── supabase_service.dart     # كل API calls
│   │   ├── notification_service.dart # FCM + Local Notifications
│   │   └── local_storage_service.dart # Hive offline storage
│   └── utils/
│       └── app_utils.dart       # مساعدات عامة
├── data/
│   └── models/
│       └── models.dart          # CourseModel, LessonModel, UserModel...
├── presentation/
│   ├── themes/
│   │   └── app_colors.dart      # لوحة الألوان
│   ├── providers/
│   │   └── providers.dart       # Riverpod providers
│   ├── pages/
│   │   ├── splash/
│   │   ├── onboarding/
│   │   ├── auth/
│   │   │   ├── login_screen.dart
│   │   │   ├── register_screen.dart
│   │   │   └── interests_screen.dart
│   │   ├── main/
│   │   │   └── main_shell.dart  # Bottom Navigation
│   │   ├── home/
│   │   ├── courses/
│   │   ├── lesson/
│   │   ├── quiz/
│   │   ├── profile/
│   │   ├── search/
│   │   └── certificate/
│   └── widgets/
│       ├── common/
│       │   ├── custom_button.dart
│       │   ├── custom_text_field.dart
│       │   ├── app_snackbar.dart
│       │   └── loading_widgets.dart
│       ├── course_card.dart
│       └── gamification_widgets.dart
└── routes/
    └── app_router.dart          # GoRouter navigation
```

---

## 🔑 بيانات Supabase (موجودة في app_constants.dart)

```
URL: https://aigfhxrvfotgccfnovtv.supabase.co
Anon Key: eyJhbGci...
```

---

## ⚠️ ملاحظات مهمة

1. **google-services.json**: يجب استبدال الملف الموجود بالملف الحقيقي من Firebase
2. **AdMob**: استبدل App ID في AndroidManifest.xml برقمك الحقيقي
3. **Code Signing**: أنشئ keystore قبل رفع التطبيق للـ Play Store
4. **YouTube API**: Key محفوظ في Supabase Secrets (غير مضمّن في الكود)

---

## 📦 المكتبات الرئيسية

| المكتبة | الاستخدام |
|---------|-----------|
| `supabase_flutter` | Backend + Auth |
| `flutter_riverpod` | State Management |
| `go_router` | Navigation |
| `youtube_player_flutter` | YouTube Player |
| `hive_flutter` | Local Storage |
| `google_fonts` | Cairo Font |
| `cached_network_image` | Image Caching |
| `shimmer` | Loading UI |
| `firebase_messaging` | Push Notifications |
| `share_plus` | Share Certificates |
| `pdf` | Certificate Generation |
| `fl_chart` | Charts |
| `percent_indicator` | Progress Bars |

---

## 🎨 نظام الألوان

| اللون | HEX | الاستخدام |
|-------|-----|-----------|
| Primary | `#2ECC71` | أزرار، تقدم، عناصر رئيسية |
| Secondary | `#3498DB` | روابط، عناصر ثانوية |
| Accent | `#F39C12` | XP، شارات، تنبيهات |
| Background | `#F8FAF9` | خلفية الشاشات |
| Text Primary | `#1A2E22` | نصوص رئيسية |

---

Built with ❤️ for Arabic learners worldwide
