// supabase/functions/fetch-youtube-playlist/index.ts
// Deploy: supabase functions deploy fetch-youtube-playlist

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { playlistUrl, courseId } = await req.json()

    if (!playlistUrl || !courseId) {
      return new Response(
        JSON.stringify({ error: 'playlistUrl and courseId are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Extract playlist ID
    const playlistIdMatch = playlistUrl.match(/[?&]list=([a-zA-Z0-9_-]+)/)
    const playlistId = playlistIdMatch?.[1]

    if (!playlistId) {
      return new Response(
        JSON.stringify({ error: 'Invalid YouTube playlist URL' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const youtubeApiKey = Deno.env.get('YOUTUBE_API_KEY')
    if (!youtubeApiKey) throw new Error('YouTube API key not configured')

    // Fetch playlist items
    const videos: any[] = []
    let pageToken: string | undefined

    do {
      const url = new URL(
        'https://www.googleapis.com/youtube/v3/playlistItems'
      )
      url.searchParams.set('part', 'snippet,contentDetails')
      url.searchParams.set('playlistId', playlistId)
      url.searchParams.set('maxResults', '50')
      url.searchParams.set('key', youtubeApiKey)
      if (pageToken) url.searchParams.set('pageToken', pageToken)

      const res = await fetch(url.toString())
      if (!res.ok) throw new Error(`YouTube API error: ${res.status}`)

      const data = await res.json()
      videos.push(...(data.items || []))
      pageToken = data.nextPageToken
    } while (pageToken)

    // Fetch video durations
    const videoIds = videos
      .map((v) => v.contentDetails?.videoId)
      .filter(Boolean)
      .join(',')

    const durationsRes = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=${videoIds}&key=${youtubeApiKey}`
    )
    const durationsData = await durationsRes.json()
    const durationMap: Record<string, number> = {}

    for (const item of durationsData.items || []) {
      const iso = item.contentDetails?.duration || 'PT0S'
      const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
      if (match) {
        const h = parseInt(match[1] || '0')
        const m = parseInt(match[2] || '0')
        const s = parseInt(match[3] || '0')
        durationMap[item.id] = h * 3600 + m * 60 + s
      }
    }

    // Insert lessons into Supabase
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const lessons = videos.map((v, idx) => ({
      course_id: courseId,
      title: v.snippet?.title || `Lesson ${idx + 1}`,
      description: v.snippet?.description?.substring(0, 500),
      youtube_video_id: v.contentDetails?.videoId,
      video_url: `https://www.youtube.com/watch?v=${v.contentDetails?.videoId}`,
      thumbnail_url: v.snippet?.thumbnails?.medium?.url,
      duration_seconds: durationMap[v.contentDetails?.videoId] || 0,
      order_index: idx,
      is_active: true,
      is_free_preview: idx === 0, // First lesson is free preview
    }))

    // Delete existing lessons first
    await supabaseAdmin.from('lessons').delete().eq('course_id', courseId)

    // Insert new lessons
    const { error } = await supabaseAdmin.from('lessons').insert(lessons)
    if (error) throw error

    // Update course total_lessons and duration
    const totalDuration = Object.values(durationMap).reduce((a, b) => a + b, 0)
    await supabaseAdmin
      .from('courses')
      .update({
        total_lessons: lessons.length,
        total_duration_minutes: Math.ceil(totalDuration / 60),
        youtube_playlist_id: playlistId,
        youtube_playlist_url: playlistUrl,
      })
      .eq('id', courseId)

    return new Response(
      JSON.stringify({
        success: true,
        lessonsCount: lessons.length,
        totalDurationMinutes: Math.ceil(totalDuration / 60),
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})
