// supabase/functions/generate-quiz/index.ts
// Deploy: supabase functions deploy generate-quiz

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { courseId, lessonId, lessonTitle, lessonDescription, questionCount = 5 } =
      await req.json()

    const geminiApiKey = Deno.env.get('GEMINI_API_KEY')
    if (!geminiApiKey) throw new Error('Gemini API key not configured')

    const prompt = `أنت مدرس متخصص. قم بإنشاء ${questionCount} أسئلة اختبار باللغة العربية للدرس التالي:

العنوان: ${lessonTitle}
الوصف: ${lessonDescription || 'درس تعليمي'}

أنشئ الأسئلة بصيغة JSON فقط (بدون أي نص إضافي) بالشكل التالي:
{
  "questions": [
    {
      "question_text": "نص السؤال",
      "question_type": "multiple_choice",
      "options": ["خيار 1", "خيار 2", "خيار 3", "خيار 4"],
      "correct_answer": "الخيار الصحيح",
      "explanation": "شرح الإجابة"
    }
  ]
}

القواعد:
- جميع الأسئلة باللغة العربية
- كل سؤال له 4 خيارات
- الإجابة الصحيحة يجب أن تكون نصياً مطابقاً لأحد الخيارات
- أسئلة متنوعة تختبر الفهم الحقيقي`

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          },
        }),
      }
    )

    if (!geminiRes.ok) {
      const err = await geminiRes.text()
      throw new Error(`Gemini API error: ${err}`)
    }

    const geminiData = await geminiRes.json()
    const responseText =
      geminiData.candidates?.[0]?.content?.parts?.[0]?.text || ''

    // Parse JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/)
    if (!jsonMatch) throw new Error('Failed to parse AI response')

    const parsed = JSON.parse(jsonMatch[0])
    const questions = parsed.questions || []

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Create quiz
    const { data: quiz, error: quizError } = await supabaseAdmin
      .from('quizzes')
      .insert({
        course_id: courseId,
        lesson_id: lessonId || null,
        title: `اختبار: ${lessonTitle}`,
        title_ar: `اختبار: ${lessonTitle}`,
        pass_percentage: 70,
        max_attempts: 3,
        is_active: false, // Pending admin review
        is_ai_generated: true,
      })
      .select()
      .single()

    if (quizError) throw quizError

    // Insert questions
    const questionsToInsert = questions.map((q: any, idx: number) => ({
      quiz_id: quiz.id,
      question_text: q.question_text,
      question_type: q.question_type || 'multiple_choice',
      options: q.options || [],
      correct_answer: q.correct_answer,
      explanation: q.explanation,
      order_index: idx,
      is_approved: false,
      is_ai_generated: true,
    }))

    const { error: qError } = await supabaseAdmin
      .from('questions')
      .insert(questionsToInsert)

    if (qError) throw qError

    return new Response(
      JSON.stringify({
        success: true,
        quizId: quiz.id,
        questionsCount: questions.length,
        message: 'تم إنشاء الاختبار بنجاح وهو بانتظار المراجعة',
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})
