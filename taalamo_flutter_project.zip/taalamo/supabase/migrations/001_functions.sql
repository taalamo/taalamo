-- Migration: increment_user_xp function
-- Run in Supabase SQL editor

CREATE OR REPLACE FUNCTION increment_user_xp(uid UUID, xp INTEGER)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.users
  SET
    total_xp = total_xp + xp,
    level = CASE
      WHEN total_xp + xp >= 7500 THEN 10
      WHEN total_xp + xp >= 5500 THEN 9
      WHEN total_xp + xp >= 4000 THEN 8
      WHEN total_xp + xp >= 2750 THEN 7
      WHEN total_xp + xp >= 1750 THEN 6
      WHEN total_xp + xp >= 1000 THEN 5
      WHEN total_xp + xp >= 500  THEN 4
      WHEN total_xp + xp >= 250  THEN 3
      WHEN total_xp + xp >= 100  THEN 2
      ELSE 1
    END,
    updated_at = NOW()
  WHERE id = uid;
END;
$$;

-- Update streak function
CREATE OR REPLACE FUNCTION update_user_streak(uid UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  last_active DATE;
  today DATE := CURRENT_DATE;
BEGIN
  SELECT last_active_date INTO last_active
  FROM public.users WHERE id = uid;

  IF last_active = today - INTERVAL '1 day' THEN
    -- Consecutive day
    UPDATE public.users
    SET streak_days = streak_days + 1,
        last_active_date = today,
        updated_at = NOW()
    WHERE id = uid;
  ELSIF last_active < today - INTERVAL '1 day' THEN
    -- Streak broken
    UPDATE public.users
    SET streak_days = 1,
        last_active_date = today,
        updated_at = NOW()
    WHERE id = uid;
  ELSIF last_active = today THEN
    -- Same day, no change
    NULL;
  ELSE
    UPDATE public.users
    SET streak_days = 1,
        last_active_date = today,
        updated_at = NOW()
    WHERE id = uid;
  END IF;
END;
$$;

-- Auto-create user profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Create trigger for new users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE handle_new_user();
